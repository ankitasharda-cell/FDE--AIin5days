# 🎓 AI in Five Days — Enterprise Multi-Agent Tutor (ADK + Antigravity)

> **Production-Grade Multi-Agent AI Engineering Coach with ChromaDB RAG, Async Memory, Strategic Model Routing, OpenTelemetry Tracing, PII Redaction, and Terraform IaC**

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Google ADK](https://img.shields.io/badge/Framework-Google%20ADK-4285F4.svg)](https://google.github.io/adk-docs/)
[![OpenTelemetry](https://img.shields.io/badge/Tracing-OpenTelemetry-blueviolet.svg)](https://opentelemetry.io/)
[![Terraform](https://img.shields.io/badge/IaC-Terraform%205.0-purple.svg)](https://www.terraform.io/)

---

## 📌 1. Problem & Solution Statement

- **Problem:** Engineers onboarding into production AI agent development struggle to bridge theoretical LLM prompting with enterprise **AgentOps** standards (strict Pydantic tool schemas, context compaction, multi-agent orchestration, OpenTelemetry tracing, PII redaction, and CI/CD evaluation). Static documentation lacks interactive coaching, milestone tracking, and automated rubric verification.
- **Solution:** **AI in Five Days Tutor (`ai_five_days_tutor`)** is a multi-agent AI coaching system built with **Google ADK** and packaged as an **Antigravity Plugin**. A central Coordinator Agent routes learner requests across four specialized subagents (`CurriculumResearchAgent`, `AssessmentGraderAgent`, `StudyNotesMemoryAgent`, and `ProgressAndCapstoneAgent`), combining ChromaDB RAG, persistent SQLite session/milestone tracking, non-blocking async memory workers, Human-in-the-Loop (HITL) approval hooks, and full OpenTelemetry observability.

---

## 🏛️ 2. Multi-Agent System Architecture

```mermaid
flowchart TD
    User(["Learner (ADK Web / Antigravity UI / CLI)"]) --> InGuard["1. InputSafetyGuardrail & PII Scrubber"]
    InGuard --> Router["2. Strategic ModelRouter (Flash vs Pro)"]
    Router --> Coord["3. TutorCoordinatorAgent (ADK Root Agent)"]

    subgraph Subagents["Specialized ADK Worker Subagents"]
        Coord -->|"Curriculum & RAG (gemini-2.5-flash)"| ResAgent["CurriculumResearchAgent"]
        Coord -->|"Quizzes & Badges (gemini-2.5-flash)"| GradeAgent["AssessmentGraderAgent"]
        Coord -->|"Async Study Notes (gemini-2.5-flash)"| NoteAgent["StudyNotesMemoryAgent"]
        Coord -->|"Capstone & Architecture (gemini-2.5-pro)"| CapAgent["ProgressAndCapstoneAgent"]
    end

    subgraph Tools["Pydantic-Validated Tools with Guided Recovery"]
        ResAgent --> T1["retrieve_daily_curriculum_module"]
        ResAgent --> T2["search_curriculum_knowledge_base"]
        GradeAgent --> T3["administer_daily_knowledge_quiz"]
        GradeAgent --> T4["evaluate_learner_quiz_submission"]
        NoteAgent --> T5["record_learner_study_note"]
        NoteAgent --> T6["query_learner_study_notes"]
        CapAgent --> T7["get_learner_training_progress"]
        CapAgent --> HITL["HumanInTheLoopGate"] --> T8["reset_learner_training_progress"]
    end

    subgraph Memory["Persistent Storage & Context Compaction"]
        T2 --> Chroma[("ChromaDB Vector Store / Vertex AI Search")]
        T4 & T5 & T7 & T8 --> SQLite[("SQLite Session & Milestone DB")]
        T5 -.-> AsyncWorker["AsyncMemoryWorker (ThreadPool / asyncio)"]
        Coord -.-> Compactor["ContextCompactor (Sliding Window + Token Cap)"]
    end

    subgraph Observability["Observability & Security Layer"]
        Tools -.-> OTel["OpenTelemetry Spans (Intent vs Outcome JSON Logs)"]
        OTel -.-> Redactor["PIIRedactor (Regex + Cloud DLP API)"]
    end

    Coord --> OutGuard["4. OutputGroundingGuardrail"] --> User
```

---

## 🧪 3. Alignment with the 95-Point AgentOps Rubric

Every one of the **19 grading criteria (95 points total)** is directly implemented and verified by automated unit and regression tests:

| Pillar | Criterion (5 pts each) | Implementation in Repository |
| :--- | :--- | :--- |
| **1. Tool & Interface Design (20 pts)** | **Comprehensive Tool Docstrings** | Google-style docstrings with `Args:` and `Returns:` on all 8 tools in `ai_five_days_tutor/tools/curriculum_tools.py`. |
| | **Descriptive Naming** | Specific verb-noun names: `retrieve_daily_curriculum_module`, `search_curriculum_knowledge_base`, `administer_daily_knowledge_quiz`, `evaluate_learner_quiz_submission`, `record_learner_study_note`, `reset_learner_training_progress`. |
| | **Explicit JSON Schemas** | Strict Pydantic `BaseModel` input/output schemas (`CurriculumLookupInput`, `SearchKnowledgeInput`, `QuizEvaluationInput`, `SaveStudyNoteInput`) exported via `.model_json_schema()`. |
| | **Guided Error Handling** | Validation and runtime errors return structured dictionaries with `recovery_guidance` instructions back to the LLM instead of raising unhandled exceptions. |
| **2. Context & Memory (20 pts)** | **Robust System Instructions** | 4-part system constitution in `ai_five_days_tutor/prompts.py` (`TUTOR_CONSTITUTION_SYSTEM_PROMPT`). |
| | **History Compaction** | `ContextCompactor` in `ai_five_days_tutor/memory/compaction.py` implementing token-budget truncation, sliding windows, turn summarization, and ADK compaction config. |
| | **Persistent Session State** | SQLite (`ai_five_days_tutor/storage/database.py`) + ChromaDB & Vertex AI Search connector (`ai_five_days_tutor/storage/vector_store.py`). |
| | **Async Memory Operations** | `AsyncMemoryWorker` (`ai_five_days_tutor/storage/async_worker.py`) executing background vector indexing and note persistence via `asyncio` and `ThreadPoolExecutor`. |
| **3. Orchestration & Logic (20 pts)** | **Multi-Agent Patterns** | Coordinator (`root_agent`), 4 specialist `LlmAgent` subagents, and `SequentialAgent` pipeline in `ai_five_days_tutor/agent.py` & `ai_five_days_tutor/multi_agent.py`. |
| | **Strategic Model Routing** | `ModelRouter` routes fast lookups/quizzes to `gemini-2.5-flash` and complex Capstone architecture synthesis to `gemini-2.5-pro`. |
| | **Guardrails & Policy Plugins** | `InputSafetyGuardrail` (prompt injection blocker) and `OutputGroundingGuardrail` (self-evaluation check) in `ai_five_days_tutor/guardrails.py`. |
| | **Human-in-the-Loop Hooks** | `HumanInTheLoopGate` (`before_tool_callback`) halts `reset_learner_training_progress` until `confirm_human_approval=True` is provided. |
| **4. Observability & Tracing (20 pts)** | **Structured JSON Logging** | `StructuredJSONFormatter` in `ai_five_days_tutor/telemetry/tracer.py` emitting structured JSON logs (no bare `print` calls). |
| | **Intent vs. Outcome Capture** | Logs `tool_intent_before_execution` (`intended_action`) prior to execution and `tool_outcome_after_execution` (`actual_status`, latency) afterward. |
| | **Distributed Tracing** | OpenTelemetry `TracerProvider` and nested spans (`agent.turn`, `tool.<name>`) in `ai_five_days_tutor/telemetry/tracer.py`. |
| | **PII Redaction** | `PIIRedactor` scrubs emails, phones, SSNs, IPs, and API keys (with optional Google Cloud DLP `dlp_v2` integration) before logging or DB writes. |
| **5. Infrastructure & CI/CD (15 pts)** | **Automated Evaluation Suites** | Golden benchmark dataset (`tests/eval_dataset.json`) + `pytest` regression suite (`tests/test_agent_eval.py`, `tests/test_tools.py`, `tests/test_guardrails_and_telemetry.py`). |
| | **Infrastructure as Code** | Terraform configs (`terraform/main.tf`, `variables.tf`, `outputs.tf`), `Dockerfile`, GitHub Actions CI (`.github/workflows/ci.yml`), and `adk` / `agent` CLI usage below. |
| | **Secure Secret Management** | `SecretManagerClient` (`ai_five_days_tutor/storage/secret_manager.py`) fetches `GEMINI_API_KEY` from Google Cloud Secret Manager with `.env` fallback. |

---

## 📂 4. Repository Structure

```text
.
├── README.md
├── pyproject.toml
├── requirements.txt
├── Dockerfile
├── cli.py                                  # Interactive CLI runner
├── plugin.json                             # Antigravity root plugin manifest
├── assets/
│   └── logo.svg                            # Plugin icon
├── ai_five_days_tutor/                     # Core Python & Google ADK package
│   ├── __init__.py
│   ├── config.py                           # Pydantic Settings & Secret Manager wiring
│   ├── prompts.py                          # System prompt constitution
│   ├── guardrails.py                       # Input/Output guardrails & HITL gate
│   ├── agent.py                            # Google ADK Coordinator & Subagents
│   ├── multi_agent.py                      # Multi-Agent orchestrator & ModelRouter
│   ├── memory/
│   │   └── compaction.py                   # Sliding-window & token compaction
│   ├── storage/
│   │   ├── secret_manager.py               # Google Cloud Secret Manager client
│   │   ├── database.py                     # SQLite session, notes & milestone store
│   │   ├── vector_store.py                 # ChromaDB & Vertex AI Search RAG
│   │   └── async_worker.py                 # Non-blocking AsyncMemoryWorker
│   ├── telemetry/
│   │   └── tracer.py                       # OpenTelemetry, JSON logs & PII redactor
│   └── tools/
│       └── curriculum_tools.py             # Pydantic-validated tools & schemas
├── .agents/                                # Antigravity Custom Agent & Skill bundle
│   └── agents/
│       └── ai_five_days_tutor/
│           ├── agent.md
│           └── skills/five_day_ai_curriculum/
│               ├── SKILL.md
│               └── references/             # Day 1 - Day 5 progressive-disclosure docs
├── terraform/                              # Infrastructure as Code (IaC)
│   ├── main.tf
│   ├── variables.tf
│   └── outputs.tf
└── tests/                                  # Automated Unit & Golden Evaluation Suite
    ├── eval_dataset.json
    ├── test_agent_eval.py
    ├── test_tools.py
    └── test_guardrails_and_telemetry.py
```

---

## 🚀 5. Quick Start & CLI Usage

### 1. Install Dependencies
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Run with Google ADK CLI (`adk web` / `adk run`) or Interactive CLI
```bash
# Launch the Google ADK Web UI
adk web

# Run via ADK terminal CLI
adk run ai_five_days_tutor

# Run the standalone multi-agent interactive CLI
python3 cli.py
```

### 3. Run in Antigravity (Custom Agent & Plugin CLI)
```bash
# Copy the plugin into your Antigravity global plugins directory:
cp -r . ~/.gemini/config/plugins/ai-five-days-tutor/

# Or invoke programmatically via Antigravity agentapi CLI:
agentapi chat start --agent ai-five-days-tutor --prompt "Start Day 1"
```

### 4. Run Automated Golden Evaluation & Unit Tests
```bash
pytest -v
```

### 5. Provision Cloud Infrastructure with Terraform
```bash
cd terraform
terraform init
terraform plan -var="project_id=your-gcp-project-id"
terraform apply -var="project_id=your-gcp-project-id"
```
