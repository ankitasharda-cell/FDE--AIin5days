"""Golden Dataset Regression Evaluation Suite verifying multi-agent accuracy, routing, and SLAs."""

import json
from pathlib import Path
import unittest

from ai_five_days_tutor.multi_agent import AIFiveDaysTutorOrchestrator


class TestGoldenDatasetEvaluation(unittest.TestCase):
    """Evaluates the multi-agent tutor against the golden benchmark dataset."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.dataset_path = Path(__file__).parent / "eval_dataset.json"
        cls.orchestrator = AIFiveDaysTutorOrchestrator(session_id="golden_eval_session")

    def test_golden_dataset_regression_suite(self) -> None:
        """Run all golden evaluation cases and assert >= 95% accuracy and < 2000ms SLA."""
        self.assertTrue(self.dataset_path.exists(), "eval_dataset.json must exist")
        with open(self.dataset_path, "r", encoding="utf-8") as fh:
            cases = json.load(fh)

        passed = 0
        for case in cases:
            result = self.orchestrator.chat(case["prompt"])
            response_text = result["response"]

            self.assertEqual(
                result["routed_intent"],
                case["expected_intent"],
                f"[{case['eval_id']}] Intent routing mismatch",
            )
            self.assertEqual(
                result["selected_model"],
                case["expected_model"],
                f"[{case['eval_id']}] Strategic model routing mismatch",
            )
            self.assertLess(
                result["total_duration_ms"],
                2000.0,
                f"[{case['eval_id']}] Latency SLA exceeded",
            )

            matched = [
                kw for kw in case["expected_keywords"] if kw.lower() in response_text.lower()
            ]
            if len(matched) == len(case["expected_keywords"]):
                passed += 1

        accuracy = (passed / len(cases)) * 100.0
        self.assertGreaterEqual(
            accuracy,
            95.0,
            f"Golden dataset accuracy {accuracy:.1f}% fell below 95.0% threshold",
        )


if __name__ == "__main__":
    unittest.main()
