"""Automated test and golden-dataset regression evaluation package."""
