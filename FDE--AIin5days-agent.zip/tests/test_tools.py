"""Unit tests for Pydantic tool schemas, guided error recovery, and HITL confirmation gates."""

import unittest

from ai_five_days_tutor.tools.curriculum_tools import (
    CURRICULUM_LOOKUP_SCHEMA,
    QUIZ_EVALUATION_SCHEMA,
    RESET_PROGRESS_SCHEMA,
    SAVE_STUDY_NOTE_SCHEMA,
    SEARCH_KNOWLEDGE_SCHEMA,
    administer_daily_knowledge_quiz,
    evaluate_learner_quiz_submission,
    get_learner_training_progress,
    query_learner_study_notes,
    record_learner_study_note,
    reset_learner_training_progress,
    retrieve_daily_curriculum_module,
    search_curriculum_knowledge_base,
)


class TestTutorToolsAndSchemas(unittest.TestCase):
    """Verifies Pillar 1 (Tool & Interface Design) and Pillar 3 (HITL Hooks)."""

    def test_explicit_json_schemas_exposed(self) -> None:
        """All tools must expose explicit Pydantic JSON schemas."""
        for schema in [
            CURRICULUM_LOOKUP_SCHEMA,
            SEARCH_KNOWLEDGE_SCHEMA,
            QUIZ_EVALUATION_SCHEMA,
            SAVE_STUDY_NOTE_SCHEMA,
            RESET_PROGRESS_SCHEMA,
        ]:
            self.assertIn("properties", schema)

    def test_curriculum_lookup_and_guided_error_recovery(self) -> None:
        """Valid days return curriculum data; invalid days return recovery_guidance."""
        ok = retrieve_daily_curriculum_module(day=1)
        self.assertEqual(ok["status"], "success")
        self.assertEqual(ok["badge"], "Prompt Architect")

        err = retrieve_daily_curriculum_module(day=99)
        self.assertEqual(err["status"], "error")
        self.assertIn("recovery_guidance", err)
        self.assertTrue(len(err["recovery_guidance"]) > 10)

    def test_knowledge_base_rag_and_recovery(self) -> None:
        """Vector search returns grounded chunks and recovery_guidance on invalid inputs."""
        res = search_curriculum_knowledge_base(query="OpenTelemetry tracing", top_k=2)
        self.assertEqual(res["status"], "success")
        self.assertGreaterEqual(res["total_matches"], 1)

        bad = search_curriculum_knowledge_base(query="x", top_k=50)
        self.assertEqual(bad["status"], "error")
        self.assertIn("recovery_guidance", bad)

    def test_quiz_grading_and_milestone_persistence(self) -> None:
        """Quiz grading unlocks badges and updates SQLite milestones."""
        quiz = administer_daily_knowledge_quiz(day=2)
        self.assertEqual(quiz["status"], "success")

        graded = evaluate_learner_quiz_submission(day=2, selected_option="A")
        self.assertTrue(graded["is_correct"])
        self.assertEqual(graded["badge_unlocked"], "Toolsmith")

        progress = get_learner_training_progress()
        self.assertIn("Toolsmith", progress["unlocked_badges"])

    def test_async_note_recording_and_pii_redaction(self) -> None:
        """Notes saved via AsyncMemoryWorker scrub PII before persisting to SQLite."""
        saved = record_learner_study_note(
            title="Async RAG Note",
            content="Email user@corp.example.com or key AIzaSyB1234567890abcdef",
            day=3,
            tags=["rag"],
            run_async=True,
        )
        self.assertEqual(saved["status"], "success")
        self.assertIn("[REDACTED_EMAIL]", saved["note"]["content"])
        self.assertIn("[REDACTED_API_KEY]", saved["note"]["content"])

        queried = query_learner_study_notes(query="Async RAG", day=3)
        self.assertGreaterEqual(queried["count"], 1)

    def test_hitl_gate_on_reset_progress(self) -> None:
        """Resetting progress must block until confirm_human_approval=True is passed."""
        halted = reset_learner_training_progress(confirm_human_approval=False)
        self.assertEqual(halted["status"], "requires_human_approval")
        self.assertIn("recovery_guidance", halted)

        approved = reset_learner_training_progress(confirm_human_approval=True)
        self.assertEqual(approved["status"], "success")


if __name__ == "__main__":
    unittest.main()
