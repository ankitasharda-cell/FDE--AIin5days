# AI in Five Days Tutor — Plugin Guardrails

- Always verify tool inputs against explicit Pydantic schemas and follow `recovery_guidance` on validation errors.
- Redact sensitive PII (emails, phone numbers, SSNs, API keys) before writing to logs or persistent storage.
- Require explicit human confirmation before executing destructive or state-resetting operations.
