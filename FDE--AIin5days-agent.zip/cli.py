"""Interactive command-line interface for the AI in Five Days Multi-Agent Tutor."""

import sys

from ai_five_days_tutor.multi_agent import tutor_orchestrator


def main() -> None:
    """Run an interactive terminal session with the AI in Five Days Tutor."""
    sys.stdout.write(
        "====================================================================\n"
        "  AI in Five Days — Interactive Multi-Agent Tutor (ADK + Antigravity)\n"
        "  Type 'exit' or 'quit' to end the session.\n"
        "====================================================================\n\n"
    )
    while True:
        try:
            user_input = input("Learner > ").strip()
        except (EOFError, KeyboardInterrupt):
            sys.stdout.write("\nSession ended.\n")
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit"}:
            sys.stdout.write("Goodbye!\n")
            break

        result = tutor_orchestrator.chat(user_input)
        sys.stdout.write(
            f"\n[{result['selected_subagent']} | model={result['selected_model']} | "
            f"{result['total_duration_ms']}ms]\n"
            f"{result['response']}\n\n"
        )


if __name__ == "__main__":
    main()
