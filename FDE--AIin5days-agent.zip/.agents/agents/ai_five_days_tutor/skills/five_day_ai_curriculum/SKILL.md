---
name: five-day-ai-curriculum
description: >-
  Curriculum, daily lesson plans, hands-on lab specifications, quizzes, and
  progress tracker templates for the "AI in Five Days" training tutor agent.
  Use when teaching any day of the 5-day AI & Agents training program, setting up
  the learner's progress artifact, running a daily hands-on lab, or grading the
  Day 5 Capstone project.
---

# AI in Five Days — Curriculum & Instructor Runbook

Use this skill to deliver structured, interactive training sessions for the **AI in Five Days** program.

## Progressive Disclosure Map

Do **not** read all 5 reference files at once. Read only the reference file for the day the learner is currently studying:

- **Day 1 (Foundations, Prompting & ReAct)**: [day1_foundations.md](references/day1_foundations.md)
- **Day 2 (Tools, Grounding & MCP)**: [day2_tools_and_knowledge.md](references/day2_tools_and_knowledge.md)
- **Day 3 (Context Engineering, Rules & Skills)**: [day3_context_and_skills.md](references/day3_context_and_skills.md)
- **Day 4 (Multi-Agent Systems, Subagents & ADK)**: [day4_multi_agent_and_adk.md](references/day4_multi_agent_and_adk.md)
- **Day 5 (Evaluation, Guardrails & Capstone)**: [day5_capstone.md](references/day5_capstone.md)

---

## Diagnostic & Onboarding Flow

When a learner starts the training for the first time:

1. Call `ask_question` with two onboarding questions:
   - **Experience Level**:
     - `(Recommended) Intermediate — I use AI chat/coding tools daily and want to build custom skills & agents`
     - `Beginner — I'm new to prompt engineering, LLMs, and agent workflows`
     - `Advanced — I've built agents before and want deep dives into ADK, multi-agent orchestration, and evals`
   - **Starting Module**:
     - `(Recommended) Day 1: Foundations of LLMs, Prompting & Agentic Thinking`
     - `Day 2: Extending Agents with Tools, Code Search & MCP`
     - `Day 3: Context Engineering, Rules & Reusable Skills`
     - `Day 4: Multi-Agent Orchestration (Subagents, Swarms & ADK)`
     - `Day 5: Agent Evaluation, Safety Guardrails & Capstone Project`

2. Initialize the learner's progress tracker artifact at `<appDataDir>/brain/<conversation-id>/ai_5_day_training_progress.md` using the template below.

---

## Progress Tracker Artifact Template

Create `<appDataDir>/brain/<conversation-id>/ai_5_day_training_progress.md` with `ArtifactMetadata` (`UserFacing: true`, `RequestFeedback: false`):

```markdown
# 🎓 AI in Five Days — Learner Progress Tracker

**Learner**: `<username>`
**Track / Level**: `<Beginner | Intermediate | Advanced>`
**Current Module**: `Day <N>`

## 🏅 Badges & Module Status

| Day | Module | Concept Bite | Hands-On Lab | Knowledge Quiz | Badge |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **Day 1** | Foundations & Agentic Thinking | ⬜ | ⬜ | ⬜ | 🔒 *Prompt Architect* |
| **Day 2** | Tools, Grounding & MCP | ⬜ | ⬜ | ⬜ | 🔒 *Toolsmith* |
| **Day 3** | Context, Rules & Skills | ⬜ | ⬜ | ⬜ | 🔒 *Skill Author* |
| **Day 4** | Multi-Agent Systems & ADK | ⬜ | ⬜ | ⬜ | 🔒 *Orchestrator* |
| **Day 5** | Evaluation, Safety & Capstone | ⬜ | ⬜ | ⬜ | 🔒 *AI Agent Engineer* |

## 📝 Lab Deliverables & Notes

- **Day 1 Deliverable**: *(Pending)*
- **Day 2 Deliverable**: *(Pending)*
- **Day 3 Deliverable**: *(Pending)*
- **Day 4 Deliverable**: *(Pending)*
- **Day 5 Capstone**: *(Pending)*
```

Update checkboxes (`⬜` → `🔄` in progress → `✅` completed) and unlock badges (`🔒` → `🏆`) as the learner finishes each phase.
