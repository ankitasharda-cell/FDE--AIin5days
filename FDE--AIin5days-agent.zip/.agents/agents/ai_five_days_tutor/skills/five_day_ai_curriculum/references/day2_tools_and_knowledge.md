# Day 2: Extending Agents with Tools, Grounding & MCP

## Learning Objectives
By the end of Day 2, the learner will be able to:
1. Explain how LLM **Function Calling (Tool Use)** works via JSON schemas and tool descriptions.
2. Ground agent reasoning in internal Google sources (`cs` for Code Search, `moma_search` for internal docs, `read_file` for exact source inspection).
3. Understand how **Model Context Protocol (MCP)** connects agents to external tool servers (`mcp_config.json`).

---

## Phase 1: Concept Bite (10 min)

### 1. How Agents Choose and Call Tools
Models do not execute code directly inside their weights—instead, they inspect the **tool declarations** (name, description, and parameter JSON schema) provided in the context, emit a structured `tool_call` payload, and let the harness execute the tool and return the result.

```mermaid
sequenceDiagram
    participant User
    participant LLM as Gemini Model
    participant Harness as Agent Harness (Jetski / ADK)
    participant Tool as External Tool (cs / MCP / CLI)

    User->>LLM: "Where is AgentConfig defined?"
    Note over LLM: Inspects tool schemas & descriptions
    LLM->>Harness: tool_call: run_command("cs ... AgentConfig")
    Harness->>Tool: Execute command
    Tool-->>Harness: File paths & line numbers
    Harness-->>LLM: tool_response (Observation)
    LLM-->>User: Grounded answer with clickable file:// links
```

### 2. Why Tool Descriptions Matter as Much as Code
In both ADK Python (`def my_tool(query: str) -> dict:`) and MCP servers, **the docstring and parameter descriptions ARE the prompt** that tells the model *when* and *how* to call the tool. A vague docstring leads to bad tool calls; a clear docstring with input format examples makes tool use reliable.

---

## Phase 2: Guided Hands-On Lab (20 min)

### Lab Challenge: "Design a Grounded Tool Specification & Query Pipeline"
Ask the learner to choose one of two hands-on tracks:
- **Track A (ADK / Python Tool Design)**: Write a Python function tool in `<appDataDir>/brain/<conversation-id>/scratch/labs/day2/custom_tools.py` with full type annotations, a crystal-clear docstring (`Args:`, `Returns:`, when to use/not use), and structured dict return values (including `status` and `error_message` handling).
- **Track B (Google3 Grounding Challenge)**: Formulate a 3-step grounded research workflow using `cs` (`--tool_tag=JETSKI`), `read_file`, and `moma_search` to answer a real architectural question about a package in Google3, producing a mini report with verified `file://` line links.

**Coach Verification**:
- Inspect the learner's Python tool function (checking type hints, docstring clarity, and error return structure) or verify their grounded citations.

---

## Phase 3: Knowledge Check (5 min)

Use `ask_question` with these 2 multiple-choice questions:

1. **How does an LLM know when to invoke a specific tool and what arguments to pass?**
   - `(Recommended) By reading the tool's name, description/docstring, and parameter JSON schema in its context`
   - `By inspecting the compiled binary implementation of the tool at runtime`
   - `By trial-and-error guessing parameter names until one succeeds`

2. **When designing a custom Python function tool for an agent, what is the best practice for handling expected errors (like "item not found")?**
   - `(Recommended) Return a structured dictionary with a clear status and actionable error message so the model can self-correct`
   - `Crash the entire Python process with an unhandled SystemExit`
   - `Return an empty string with no explanation`

**Badge Unlocked**: 🏆 *Toolsmith*
