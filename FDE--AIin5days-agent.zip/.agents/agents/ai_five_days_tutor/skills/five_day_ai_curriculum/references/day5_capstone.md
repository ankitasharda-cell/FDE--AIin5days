# Day 5: Agent Evaluation, Safety Guardrails & Capstone Project

## Learning Objectives
By the end of Day 5, the learner will be able to:
1. Design deterministic and LLM-as-a-Judge **evaluations** for agents and skills (`evalin` / `pytest` with `InMemoryRunner`).
2. Enforce **Safety, Security & Operational Guardrails** (least-privilege tools, human-in-the-loop confirmation for write/external actions, CitC hygiene).
3. Design, build, and verify an end-to-end **Capstone Custom Agent** tailored to their own workflow!

---

## Phase 1: Concept Bite (10 min)

### 1. How Do You Know Your Agent Actually Works? (Evaluation)
Unlike traditional deterministic functions, changes to a prompt, skill, or tool description can subtly improve one scenario while regressing another. Production agent engineering relies on three layers of evaluation:

```mermaid
flowchart TD
    Change["Prompt / Skill / Agent Change"] --> L1["Layer 1: Trajectory & Tool Assertions (Did it call the right tool with valid args?)"]
    L1 --> L2["Layer 2: Output Rubric / LLM-as-a-Judge (Is the response accurate, grounded, and complete?)"]
    L2 --> L3["Layer 3: SxS Ablation via Evalin (Does adding the skill/agent beat the baseline?)"]
```

### 2. Production Guardrails Checklist
- **Least-Privilege Tool Allowlist**: Only grant `write_file` / `run_command` if the agent's role requires mutation; keep research/review subagents read-only.
- **Human-in-the-Loop Gates**: Require explicit user confirmation before external side effects (sending chat/email messages, modifying shared docs, submitting CLs).
- **Verification Before Action**: Always verify IDs (`b/`, `cl/`), LDAPs, and file paths before citing or mutating them.

---

## Phase 2: The Day 5 Capstone Project (30 min)

### Capstone Challenge: "Ship Your Own Custom Agent"
Guide the learner to build and verify a complete custom agent that solves a real problem in their daily work!

**Step 1 — Pick a Capstone Blueprint (or propose your own)**:
1. **Team Oncall & Bug Triage Agent**: Investigates Buganizer tickets, searches code (`cs`) & logs, and drafts a root-cause summary artifact.
2. **PR / CL Review & Readability Coach Agent**: Audits local diffs against team style rules and unit test best practices.
3. **Doc & Knowledge Synthesizer Agent**: Searches Moma, g3doc, and YAQS to build structured onboarding guides or design briefs.
4. **Custom Workflow Agent**: Any specialized agent for the learner's own team!

**Step 2 — Build the Capstone Package**:
Have the learner create:
- `agent.md` (with `name`, `description`, least-privilege `tools`, and structured `# ` prompt sections)
- At least 1 companion `SKILL.md` bundled in `skills/<skill_name>/SKILL.md`
- A 3-case **Evaluation Test Suite / Rubric** (`eval_cases.md`) defining test prompts, expected tool calls, and pass/fail criteria.

**Step 3 — Capstone Review & Graduation**:
Review the learner's Capstone Agent against the 5-point Capstone Rubric:
1. Clear `name` and trigger `description` in frontmatter
2. Least-privilege `tools` selection
3. Structured system prompt with explicit guardrails & verification protocol
4. Progressive disclosure via a companion `SKILL.md`
5. Concrete evaluation test cases (`eval_cases.md`)

---

## Phase 3: Final Knowledge Check & Graduation (5 min)

Use `ask_question` with these 2 final questions:

1. **Why is ablation testing (comparing agent performance with vs. without a skill/customization in `evalin`) important before shipping a shared skill?**
   - `(Recommended) It proves with side-by-side evidence that the skill measurably improves task success and doesn't introduce regressions`
   - `It is required to compile Markdown files into C++ binaries`
   - `It deletes all other skills in the workspace`

2. **When configuring tools for a specialized read-only code review subagent, which principle should guide your `tools:` list?**
   - `(Recommended) Least privilege—grant only read/search tools (like read_file and cs) and omit file-mutation tools`
   - `Grant every experimental tool available so the subagent can modify files unexpectedly`
   - `Disable all tools so the reviewer cannot read the code it is reviewing`

**Final Badge Unlocked**: 🏆🎓 *Certified AI in Five Days Agent Engineer!*
Update `ai_5_day_training_progress.md` to mark all 5 days complete and present a graduation summary!
