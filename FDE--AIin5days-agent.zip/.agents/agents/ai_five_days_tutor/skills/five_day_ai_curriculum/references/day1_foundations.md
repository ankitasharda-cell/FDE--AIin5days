# Day 1: Foundations of LLMs, Prompting & Agentic Thinking

## Learning Objectives
By the end of Day 1, the learner will be able to:
1. Contrast a single-turn LLM completion with an **Agentic ReAct Loop** (`Thought → Action → Observation`).
2. Structure high-signal system instructions using **Role, Context, Constraints, and Output Schema**.
3. Apply **Vibe Coding** principles—expressing clear intent, acceptance criteria, and verification constraints in natural language.

---

## Phase 1: Concept Bite (10 min)

### 1. From Chatbots to Agents: The ReAct Loop
A standard LLM prompt takes text in and predicts tokens out in a single pass. An **AI Agent** wraps the model in an execution loop where the model can reason about a goal, invoke external tools, inspect the results, and iterate until the goal is verified.

```mermaid
flowchart LR
    U["User Goal"] --> T["🧠 Thought (Plan & Reason)"]
    T --> A["🛠️ Action (Tool Call)"]
    A --> O["👀 Observation (Tool Output)"]
    O -->|"Needs more info / fix"| T
    T -->|"Goal verified"| R["✅ Final Response"]
```

### 2. The 4 Pillars of a High-Signal System Prompt
When designing an agent or writing a complex prompt, structure it around four pillars:
1. **Identity & Role**: Who is the agent, and what is its primary objective?
2. **Operational Workflow**: Step-by-step sequence (`1. Verify... 2. Execute... 3. Check...`).
3. **Explicit Guardrails**: What must the agent *never* do (e.g., never guess APIs without checking code search)?
4. **Output Contract**: Exact Markdown/JSON structure expected by the user or downstream system.

---

## Phase 2: Guided Hands-On Lab (20 min)

### Lab Challenge: "The Bug Triage Architect Prompt"
Have the learner author a structured system prompt in `<appDataDir>/brain/<conversation-id>/scratch/labs/day1/triage_prompt.md` (or directly in chat) that turns an AI assistant into a **Strict Bug Triage & Root-Cause Analyst**.

**Requirements to verify:**
1. **Role Section**: Defines the persona and scope.
2. **Investigation Protocol**: Requires checking evidence before proposing a fix.
3. **Structured Output Template**: Enforces a Markdown report with `Summary`, `Root Cause Hypothesis`, `Confidence (Low/Med/High)`, and `Verification Steps`.
4. **Anti-Hallucination Rule**: Explicitly states what to do when logs or context are missing.

**Coach Verification**:
- Read the learner's prompt, test it against a sample ambiguous bug report ("My service returns 500 intermittently after yesterday's rollout"), and show how their prompt guides the response!

---

## Phase 3: Knowledge Check (5 min)

Use `ask_question` with these 2 multiple-choice questions:

1. **In an agentic ReAct loop, what happens immediately after the agent executes a tool (`Action`)?**
   - `(Recommended) It receives an Observation (the tool's output/error) and feeds it back into the next Thought step`
   - `It immediately terminates the turn and returns the raw tool JSON to the user`
   - `It clears its context window and restarts from the user prompt`

2. **Which prompt engineering technique best prevents an agent from fabricating file paths or API signatures?**
   - `(Recommended) Adding an explicit verification guardrail requiring tool lookups before citing symbols or paths`
   - `Increasing the model temperature so it explores more creative possibilities`
   - `Writing the prompt in all caps without examples`

**Badge Unlocked**: 🏆 *Prompt Architect*
