# Day 3: Context Engineering, Rules & Reusable Skills

## Learning Objectives
By the end of Day 3, the learner will be able to:
1. Distinguish between **Rules** (`AGENTS.md`, `rules/*.md`) and **Skills** (`skills/<name>/SKILL.md`).
2. Apply **Progressive Disclosure** to keep the agent's context window fast, focused, and token-efficient.
3. Author a complete, reusable **Jetski Skill (`SKILL.md`)** with YAML frontmatter and a `references/` or `scripts/` directory.

---

## Phase 1: Concept Bite (10 min)

### 1. Context Window Hygiene & Progressive Disclosure
Stuffing every runbook, CLI flag, and style guide into an `always_on` system prompt bloats token usage, slows down every turn, and dilutes the model's attention ("lost in the middle").

Jetski solves this with **Progressive Disclosure**:

```mermaid
flowchart TD
    Prompt["System Prompt at Rest"] --> Rules["📏 Always-On Rules (Short universal invariants)"]
    Prompt --> Index["🗂️ Skill Index (Only name + 2-sentence description)"]
    Index -->|"Task matches description"| Load["📖 Read SKILL.md on demand"]
    Load -->|"Needs deep detail"| Ref["📑 Read specific references/*.md or run scripts/*"]
```

### 2. Rules vs. Skills: When to Use Which?
| Customization | Loaded When? | Token Cost at Rest | Ideal Use Case |
| :--- | :--- | :--- | :--- |
| **Rule (`AGENTS.md`)** | Always (or directory-scoped) | Paid on every turn | Short, non-negotiable invariants (e.g., "Always use `blaze-for-agents`") |
| **Skill (`SKILL.md`)** | On-demand when triggered | Near zero (metadata only) | Multi-step workflows, CLI runbooks, templates, domain playbooks |

---

## Phase 2: Guided Hands-On Lab (20–30 min)

### Lab Challenge: "Create Your Own Custom Skill (`SKILL.md`)"
Guide the learner to create a real, working skill in `<appDataDir>/brain/<conversation-id>/scratch/labs/day3/my_skill/SKILL.md` (or in their personal `~/.gemini/config/skills/` directory if they want to keep it active!):

**Checklist to verify:**
1. **Valid YAML Frontmatter**:
   - `name`: lowercase, hyphenated identifier (e.g., `pr-changelog-writer` or `team-oncall-triage`).
   - `description`: Third-person description clearly stating **what** the skill does, **Use when:** triggers, and **Don't use for:** boundaries.
2. **Concise Step-by-Step Workflow**: Actionable numbered steps in `SKILL.md`.
3. **Progressive Disclosure**: At least one companion file under `references/` linked from `SKILL.md` so bulky templates stay out of the main file.

**Coach Verification**:
- Read the learner's `SKILL.md`, check its frontmatter and trigger boundaries, and simulate how an agent decides whether to load it!

---

## Phase 3: Knowledge Check (5 min)

Use `ask_question` with these 2 multiple-choice questions:

1. **Why should multi-step domain runbooks and templates be placed in a Skill (`SKILL.md`) rather than an `always_on` Rule?**
   - `(Recommended) Skills use progressive disclosure—only their name and description are loaded at rest, saving context tokens until needed`
   - `Rules cannot contain Markdown formatting`
   - `Skills run automatically on a cron timer without user input`

2. **What is the most critical field in a `SKILL.md` YAML frontmatter for ensuring the agent activates the skill at the right time?**
   - `(Recommended) The description field, stating clearly what the skill does, when to use it, and when not to use it`
   - `The font-family field`
   - `The line count of the file`

**Badge Unlocked**: 🏆 *Skill Author*
