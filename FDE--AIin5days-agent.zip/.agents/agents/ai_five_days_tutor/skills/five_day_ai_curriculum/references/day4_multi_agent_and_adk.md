# Day 4: Multi-Agent Orchestration (Subagents, Swarms & ADK)

## Learning Objectives
By the end of Day 4, the learner will be able to:
1. Know when to split a task across **multiple agents** (context isolation, parallel fan-out, adversarial verification).
2. Orchestrate subagents in Jetski using `define_subagent`, `invoke_subagent`, `swarm`, or `run_workflow`.
3. Understand **Google ADK (Agent Development Kit)** graph workflows (`LlmAgent`, `Workflow`, function nodes, conditional routing, and fan-out/join).

---

## Phase 1: Concept Bite (10 min)

### 1. Why Multi-Agent Systems?
A single agent can get overwhelmed when a task requires:
- **Heavy Exploratory Search**: Reading 30 files clutters the main context window—delegating to a read-only `research-google` subagent returns a clean summary.
- **Parallel Independent Work**: Fanning out across 5 modules simultaneously via `run_workflow` or `swarm`.
- **Separation of Concerns (Maker-Checker)**: Having an Author agent write code and a separate Reviewer agent critique it with fresh eyes.

```mermaid
flowchart LR
    Coord["🎯 Coordinator / Workflow"] --> R1["🔍 Researcher Subagent"]
    Coord --> R2["🔍 Doc Analyst Subagent"]
    R1 --> Synth["✍️ Builder / Coder Node"]
    R2 --> Synth
    Synth --> Rev["🛡️ Adversarial Verifier"]
    Rev -->|"Needs revision"| Synth
    Rev -->|"Approved"| Done["🚀 Final Output"]
```

### 2. Orchestration Patterns in Jetski vs. ADK Python
- **In Jetski**:
  - **Subagents (`define_subagent` / `invoke_subagent`)**: Spawn a focused agent in an isolated conversation context.
  - **Workflows (`run_workflow`)**: Write Python orchestration (`parallel`, `race`, `best_of`, `verify`) over multiple agents.
  - **Custom Markdown/DCAF Agents (`agent.md` / `BUILD`)**: Package reusable personas and subagents.
- **In Google ADK (`google-adk`)**:
  - Compose `LlmAgent` nodes and plain Python function nodes inside a declarative `Workflow(edges=[...])` graph with conditional routing and `JoinNode` fan-in.

---

## Phase 2: Guided Hands-On Lab (25 min)

### Lab Challenge: "Build a Multi-Agent Maker-Checker Pipeline"
Let the learner choose their preferred implementation style:
- **Option A (Jetski Subagent / Custom Agent)**: Define a specialized subagent (either via `agent.md` or by designing a `define_subagent` + `invoke_subagent` Maker-Checker flow) where one agent drafts an artifact/code change and a second Reviewer subagent audits it against a checklist.
- **Option B (ADK Python Graph Workflow)**: Write a 2-node or 3-node ADK workflow in `<appDataDir>/brain/<conversation-id>/scratch/labs/day4/adk_workflow.py` combining a Python function preprocessing node, an `LlmAgent` generator node, and a router/verifier edge. (Consult `/google/src/cloud/corpagent-eng-ankitasharda/ai_agent_training_five_days/google3/third_party/py/google/adk/open_source_workspace/.agents/skills/adk-agent-builder/SKILL.md` if choosing Option B.)

**Coach Verification**:
- Review and run/simulate the learner's multi-agent orchestration!

---

## Phase 3: Knowledge Check (5 min)

Use `ask_question` with these 2 multiple-choice questions:

1. **What is a primary architectural benefit of delegating a broad codebase search to a subagent instead of running 25 file reads in the main agent?**
   - `(Recommended) Context isolation—the subagent absorbs the noisy intermediate search outputs and returns a concise summary to the parent agent`
   - `Subagents bypass all file permission checks`
   - `Subagents do not use any LLM tokens`

2. **In a Maker-Checker (Author-Reviewer) multi-agent pattern, why is the Reviewer run as a separate agent invocation?**
   - `(Recommended) An independent context with a dedicated review rubric avoids self-confirmation bias from the drafting conversation`
   - `Because a single agent cannot read files it just wrote`
   - `To double the latency of every request`

**Badge Unlocked**: 🏆 *Orchestrator*
