variable "project_id" {
  description = "Google Cloud Project ID for deploying the AI in Five Days Tutor Agent"
  type        = string
}

variable "region" {
  description = "Google Cloud region for Cloud Run and Artifact Registry"
  type        = string
  default     = "us-central1"
}

variable "fast_model" {
  description = "Fast Gemini model for intent routing and quiz evaluation"
  type        = string
  default     = "gemini-2.5-flash"
}

variable "reasoning_model" {
  description = "Deep-reasoning Gemini model for Capstone architecture review"
  type        = string
  default     = "gemini-2.5-pro"
}
