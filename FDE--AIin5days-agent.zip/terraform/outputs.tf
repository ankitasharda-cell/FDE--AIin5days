output "cloud_run_service_url" {
  description = "Public URL of the deployed AI in Five Days Tutor Cloud Run service"
  value       = google_cloud_run_v2_service.tutor_agent_service.uri
}

output "secret_manager_id" {
  description = "Secret Manager resource ID for the Gemini API key"
  value       = google_secret_manager_secret.gemini_api_key.id
}
