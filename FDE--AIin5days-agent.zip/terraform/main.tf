# ==============================================================================
# Terraform Infrastructure as Code (IaC) for AI in Five Days Tutor Agent
# Provisions Google Cloud Run v2, Secret Manager, Artifact Registry, & Storage
# ==============================================================================

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# 1. Google Cloud Secret Manager for Gemini API Credentials
resource "google_secret_manager_secret" "gemini_api_key" {
  secret_id = "ai-five-days-gemini-key"

  replication {
    auto {}
  }
}

# 2. Artifact Registry Repository for Agent Containers
resource "google_artifact_registry_repository" "agent_repo" {
  location      = var.region
  repository_id = "ai-five-days-tutor-repo"
  description   = "Container registry for AI in Five Days Multi-Agent Tutor"
  format        = "DOCKER"
}

# 3. Cloud Storage Bucket for Curriculum Knowledge & Vector Snapshots
resource "google_storage_bucket" "curriculum_bucket" {
  name                        = "${var.project_id}-ai-five-days-knowledge"
  location                    = var.region
  uniform_bucket_level_access = true

  versioning {
    enabled = true
  }
}

# 4. Cloud Run v2 Service Hosting the ADK Multi-Agent Service
resource "google_cloud_run_v2_service" "tutor_agent_service" {
  name     = "ai-five-days-tutor-service"
  location = var.region
  ingress  = "INGRESS_TRAFFIC_ALL"

  template {
    scaling {
      min_instance_count = 0
      max_instance_count = 5
    }

    containers {
      image = "${var.region}-docker.pkg.dev/${var.project_id}/${google_artifact_registry_repository.agent_repo.name}/ai-five-days-tutor:latest"

      resources {
        limits = {
          cpu    = "2"
          memory = "2Gi"
        }
      }

      env {
        name  = "FAST_MODEL"
        value = var.fast_model
      }

      env {
        name  = "REASONING_MODEL"
        value = var.reasoning_model
      }

      # Securely inject Gemini API key from Google Cloud Secret Manager
      env {
        name = "GEMINI_API_KEY"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.gemini_api_key.secret_id
            version = "latest"
          }
        }
      }

      ports {
        container_port = 8080
      }
    }
  }
}
