"""Context bloat management: token truncation, sliding windows, summarization, and ADK compaction."""

from typing import Any, Dict, List, Optional

from ai_five_days_tutor.config import settings
from ai_five_days_tutor.telemetry.tracer import PIIRedactor


class ContextCompactor:
    """Manages conversation history compaction to prevent context bloat and reduce token latency."""

    def __init__(
        self,
        max_turns: Optional[int] = None,
        max_token_budget: Optional[int] = None,
    ) -> None:
        self.max_turns = max_turns or settings.max_history_turns
        self.max_token_budget = max_token_budget or settings.max_context_tokens

    @staticmethod
    def estimate_tokens(text: str) -> int:
        """Estimate token count using ~4 characters per token heuristic."""
        if not text:
            return 0
        return max(1, len(text) // 4)

    def compact_conversation_history(
        self, history: List[Dict[str, str]]
    ) -> List[Dict[str, str]]:
        """Compact conversation history using a sliding window, summary synthesis, and token budget cap.

        Args:
            history (List[Dict[str, str]]): Full list of {'role': ..., 'content': ...} turns.

        Returns:
            List[Dict[str, str]]: Compacted list of turns within `max_turns` and `max_token_budget`.
        """
        if not history:
            return []

        if len(history) > self.max_turns:
            evicted = history[: -self.max_turns]
            recent = history[-self.max_turns :]
            summary_snippets = [
                f"{msg.get('role', 'user')}: {PIIRedactor.redact(msg.get('content', ''))[:80]}"
                for msg in evicted[-4:]
            ]
            compacted_summary = {
                "role": "system",
                "content": (
                    "[Compacted History Summary]: " + " | ".join(summary_snippets)
                ),
            }
            window = [compacted_summary] + recent
        else:
            window = list(history)

        total_tokens = sum(self.estimate_tokens(m.get("content", "")) for m in window)
        while len(window) > 2 and total_tokens > self.max_token_budget:
            removed = window.pop(0)
            total_tokens -= self.estimate_tokens(removed.get("content", ""))

        return window

    @staticmethod
    def get_adk_compaction_config(
        compaction_interval: int = 5, overlap_size: int = 2
    ) -> Dict[str, Any]:
        """Return ADK EventsCompactionConfig parameters for automatic session event compaction."""
        return {
            "compaction_interval": compaction_interval,
            "overlap_size": overlap_size,
            "enabled": True,
        }


context_compactor = ContextCompactor()
