"""Security guardrails, self-evaluation policy plugins, and Human-in-the-Loop (HITL) hooks."""

from dataclasses import dataclass
from typing import Any, Dict, Optional

from ai_five_days_tutor.telemetry.tracer import PIIRedactor


@dataclass
class GuardrailEvaluation:
    """Structured result of an input or output guardrail policy check."""

    passed: bool
    reason: str
    sanitized_text: Optional[str] = None


class InputSafetyGuardrail:
    """Validates incoming user prompts against prompt-injection and destructive command policies."""

    PROHIBITED_PATTERNS = [
        "ignore all previous instructions",
        "ignore previous instructions",
        "override system prompt",
        "drop table",
        "rm -rf /",
        "bypass guardrail",
    ]

    @classmethod
    def validate(cls, user_input: str) -> GuardrailEvaluation:
        """Check user input for prompt injection and scrub PII."""
        if not user_input or not user_input.strip():
            return GuardrailEvaluation(
                passed=False,
                reason="Input validation failed: query cannot be empty.",
            )

        lowered = user_input.lower()
        for pattern in cls.PROHIBITED_PATTERNS:
            if pattern in lowered:
                return GuardrailEvaluation(
                    passed=False,
                    reason=(
                        f"Security Policy Violation: Blocked prohibited prompt pattern '{pattern}'."
                    ),
                )

        sanitized = PIIRedactor.redact(user_input)
        return GuardrailEvaluation(
            passed=True,
            reason="Input passed safety and PII guardrails.",
            sanitized_text=sanitized,
        )


class OutputGroundingGuardrail:
    """Self-evaluation output guardrail ensuring non-empty, PII-free, grounded responses."""

    @classmethod
    def validate(cls, response_text: str) -> GuardrailEvaluation:
        """Verify that model output is non-empty and redact any leaked PII tokens."""
        if not response_text or not response_text.strip():
            return GuardrailEvaluation(
                passed=False,
                reason="Output self-evaluation failed: response text is empty.",
            )

        sanitized = PIIRedactor.redact(response_text)
        return GuardrailEvaluation(
            passed=True,
            reason="Output passed self-evaluation and PII redaction checks.",
            sanitized_text=sanitized,
        )


class HumanInTheLoopGate:
    """Enforces explicit human confirmation before executing high-stakes or destructive actions."""

    HIGH_STAKES_ACTIONS = {
        "reset_learner_training_progress",
        "delete_all_notes",
        "override_rubric_score",
    }

    def __init__(self, require_confirmation: bool = True) -> None:
        self.require_confirmation = require_confirmation
        self.pending_requests: Dict[str, Dict[str, Any]] = {}

    def requires_approval(self, action_name: str, params: Dict[str, Any]) -> bool:
        """Return True if the action is high-stakes and lacks explicit confirmation."""
        if not self.require_confirmation:
            return False
        if action_name in self.HIGH_STAKES_ACTIONS:
            return not bool(params.get("confirm_human_approval", False))
        return False

    def create_approval_request(
        self, request_id: str, action_name: str, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Register a pending Human-in-the-Loop approval gate and return instructions."""
        sanitized_params = PIIRedactor.redact_dict(params)
        self.pending_requests[request_id] = {
            "action_name": action_name,
            "params": sanitized_params,
            "status": "awaiting_human_confirmation",
        }
        return {
            "status": "requires_human_approval",
            "request_id": request_id,
            "action_name": action_name,
            "message": (
                f"High-stakes action '{action_name}' halted by Human-in-the-Loop (HITL) hook. "
                "Please re-invoke with confirm_human_approval=True after user confirmation."
            ),
            "recovery_guidance": (
                "Ask the human user for explicit confirmation before calling "
                f"'{action_name}' with confirm_human_approval=True."
            ),
        }


input_guardrail = InputSafetyGuardrail()
output_guardrail = OutputGroundingGuardrail()
hitl_gate = HumanInTheLoopGate(require_confirmation=True)
