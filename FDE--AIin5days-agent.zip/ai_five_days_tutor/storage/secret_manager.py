"""Google Cloud Secret Manager integration for secure credential retrieval."""

import logging
import os
from typing import Optional

logger = logging.getLogger("ai_five_days_tutor.secrets")


class SecretManagerClient:
    """Manages secret resolution from Google Cloud Secret Manager with local environment fallback."""

    @classmethod
    def get_secret(
        cls,
        secret_id: str = "ai-five-days-gemini-key",
        project_id: Optional[str] = None,
        fallback_env: str = "GEMINI_API_KEY",
    ) -> Optional[str]:
        """Fetch secret payload from Google Cloud Secret Manager or fallback to environment variable.

        Args:
            secret_id (str): The ID of the secret in Google Cloud Secret Manager.
            project_id (Optional[str]): The GCP project ID (defaults to GOOGLE_CLOUD_PROJECT).
            fallback_env (str): Environment variable key used if Secret Manager is unreachable.

        Returns:
            Optional[str]: The resolved secret string value, or None if not configured.
        """
        if fallback_env and os.getenv(fallback_env):
            return os.getenv(fallback_env)

        try:
            from google.cloud import secretmanager  # type: ignore

            client = secretmanager.SecretManagerServiceClient()
            gcp_project = project_id or os.getenv("GOOGLE_CLOUD_PROJECT", "ai-in-5-days-project")
            resource_name = f"projects/{gcp_project}/secrets/{secret_id}/versions/latest"
            response = client.access_secret_version(request={"name": resource_name})
            payload = response.payload.data.decode("UTF-8").strip()
            return payload
        except Exception as exc:
            logger.debug(
                "Secret Manager lookup skipped (%s); falling back to env var %s.",
                type(exc).__name__,
                fallback_env,
            )
            return os.getenv(fallback_env) or os.getenv(secret_id)


secret_client = SecretManagerClient()
