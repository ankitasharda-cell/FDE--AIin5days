"""Asynchronous background memory worker for non-blocking indexing and note consolidation."""

import asyncio
from concurrent.futures import Future, ThreadPoolExecutor
import logging
from typing import Any, Callable, Dict, List, Optional

from ai_five_days_tutor.storage.database import db
from ai_five_days_tutor.storage.vector_store import vector_store

logger = logging.getLogger("ai_five_days_tutor.async_worker")


class AsyncMemoryWorker:
    """Executes expensive vector indexing and SQLite memory consolidation asynchronously."""

    def __init__(self, max_workers: int = 4) -> None:
        self._executor = ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix="TutorAsyncMemoryWorker",
        )

    def submit_background_note_persistence(
        self,
        title: str,
        content: str,
        day: int = 1,
        tags: Optional[List[str]] = None,
        callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> Future:
        """Dispatch note storage and vector indexing to a background thread so UI turns never block."""

        def _background_task() -> Dict[str, Any]:
            record = db.save_study_note(title=title, content=content, day=day, tags=tags)
            vector_store.index_chunk(
                chunk_id=f"user_note_{record.id}",
                title=record.title,
                day=record.day,
                section="Learner Study Note",
                content=record.content,
            )
            payload = record.model_dump()
            if callback is not None:
                callback(payload)
            return payload

        return self._executor.submit(_background_task)

    async def async_persist_study_note(
        self,
        title: str,
        content: str,
        day: int = 1,
        tags: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Asynchronously persist a study note and index it into ChromaDB via asyncio executor."""
        loop = asyncio.get_running_loop()
        record = await loop.run_in_executor(
            self._executor,
            db.save_study_note,
            title,
            content,
            day,
            tags,
        )
        await loop.run_in_executor(
            self._executor,
            vector_store.index_chunk,
            f"user_note_{record.id}",
            record.title,
            record.day,
            "Learner Study Note",
            record.content,
            "local://study-notes",
        )
        return record.model_dump()

    async def async_index_curriculum_chunk(
        self,
        chunk_id: str,
        title: str,
        day: int,
        section: str,
        content: str,
        anchor_url: str = "https://google.github.io/adk-docs/",
    ) -> str:
        """Asynchronously index a new curriculum document chunk without blocking the event loop."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            self._executor,
            vector_store.index_chunk,
            chunk_id,
            title,
            day,
            section,
            content,
            anchor_url,
        )


async_memory_worker = AsyncMemoryWorker()
