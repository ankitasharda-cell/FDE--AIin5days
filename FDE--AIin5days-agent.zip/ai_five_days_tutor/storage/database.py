"""SQLite persistent storage for conversational session state, learner notes, and 5-day milestones."""

from datetime import datetime, timezone
from pathlib import Path
import sqlite3
from typing import Any, Dict, List, Optional

try:
    from pydantic import BaseModel, Field
except ImportError:
    from ai_five_days_tutor.pydantic_compat import BaseModel, Field

from ai_five_days_tutor.config import settings
from ai_five_days_tutor.telemetry.tracer import PIIRedactor


class StudyNoteRecord(BaseModel):
    """Pydantic schema representing a persisted learner study note."""

    id: Optional[int] = None
    title: str
    content: str
    day: int = Field(default=1, ge=1, le=5)
    tags: List[str] = Field(default_factory=list)
    created_at: str = ""


class MilestoneRecord(BaseModel):
    """Pydantic schema representing a 5-day training milestone."""

    day: int = Field(..., ge=1, le=5)
    title: str
    badge_name: str
    status: str = Field(default="pending")
    quiz_score: int = Field(default=0)
    updated_at: str = ""


DEFAULT_MILESTONES: List[Dict[str, Any]] = [
    {
        "day": 1,
        "title": "Day 1: Foundations of LLMs, Prompting & Agentic Thinking",
        "badge_name": "Prompt Architect",
        "status": "pending",
        "quiz_score": 0,
    },
    {
        "day": 2,
        "title": "Day 2: Extending Agents with Tools, Grounding & MCP",
        "badge_name": "Toolsmith",
        "status": "pending",
        "quiz_score": 0,
    },
    {
        "day": 3,
        "title": "Day 3: Context Engineering, Rules & Reusable Skills",
        "badge_name": "Skill Author",
        "status": "pending",
        "quiz_score": 0,
    },
    {
        "day": 4,
        "title": "Day 4: Multi-Agent Orchestration (Subagents & Google ADK)",
        "badge_name": "Orchestrator",
        "status": "pending",
        "quiz_score": 0,
    },
    {
        "day": 5,
        "title": "Day 5: Agent Evaluation, Safety Guardrails & Capstone Project",
        "badge_name": "Certified AI in Five Days Agent Engineer",
        "status": "pending",
        "quiz_score": 0,
    },
]


class DatabaseManager:
    """Manages persistent SQLite session history, study notes, and 5-day training milestones."""

    def __init__(self, db_path: Optional[str] = None) -> None:
        self.db_path = db_path or settings.sqlite_db_path
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_tables()
        self._seed_default_milestones()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_tables(self) -> None:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS learner_notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    day INTEGER NOT NULL DEFAULT 1,
                    tags TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS training_milestones (
                    day INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    badge_name TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    quiz_score INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS session_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.commit()

    def _seed_default_milestones(self) -> None:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) AS cnt FROM training_milestones")
            if cursor.fetchone()["cnt"] == 0:
                now = datetime.now(timezone.utc).isoformat()
                for item in DEFAULT_MILESTONES:
                    cursor.execute(
                        """
                        INSERT INTO training_milestones (day, title, badge_name, status, quiz_score, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        (
                            item["day"],
                            item["title"],
                            item["badge_name"],
                            item["status"],
                            item["quiz_score"],
                            now,
                        ),
                    )
                conn.commit()

    def save_study_note(
        self,
        title: str,
        content: str,
        day: int = 1,
        tags: Optional[List[str]] = None,
    ) -> StudyNoteRecord:
        """Persist a PII-scrubbed learner study note into SQLite."""
        clean_title = PIIRedactor.redact(title)
        clean_content = PIIRedactor.redact(content)
        clean_tags = [PIIRedactor.redact(t) for t in (tags or [])]
        tag_str = ",".join(clean_tags)
        now = datetime.now(timezone.utc).isoformat()

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO learner_notes (title, content, day, tags, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (clean_title, clean_content, day, tag_str, now),
            )
            note_id = cursor.lastrowid
            conn.commit()

        return StudyNoteRecord(
            id=note_id,
            title=clean_title,
            content=clean_content,
            day=day,
            tags=clean_tags,
            created_at=now,
        )

    def query_study_notes(
        self, query: str = "", day: Optional[int] = None
    ) -> List[StudyNoteRecord]:
        """Search persisted study notes by keyword and optional day filter."""
        wildcard = f"%{query}%"
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if day is not None:
                cursor.execute(
                    """
                    SELECT * FROM learner_notes
                    WHERE day = ? AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)
                    ORDER BY id DESC
                    """,
                    (day, wildcard, wildcard, wildcard),
                )
            else:
                cursor.execute(
                    """
                    SELECT * FROM learner_notes
                    WHERE title LIKE ? OR content LIKE ? OR tags LIKE ?
                    ORDER BY id DESC
                    """,
                    (wildcard, wildcard, wildcard),
                )
            rows = cursor.fetchall()

        return [
            StudyNoteRecord(
                id=row["id"],
                title=row["title"],
                content=row["content"],
                day=row["day"],
                tags=[t for t in row["tags"].split(",") if t],
                created_at=row["created_at"],
            )
            for row in rows
        ]

    def update_milestone(
        self, day: int, status: str = "completed", quiz_score: int = 100
    ) -> Optional[MilestoneRecord]:
        """Update completion status and quiz score for a training day (1-5)."""
        now = datetime.now(timezone.utc).isoformat()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                UPDATE training_milestones
                SET status = ?, quiz_score = ?, updated_at = ?
                WHERE day = ?
                """,
                (status, quiz_score, now, day),
            )
            conn.commit()
            cursor.execute("SELECT * FROM training_milestones WHERE day = ?", (day,))
            row = cursor.fetchone()
            if not row:
                return None
            return MilestoneRecord(
                day=row["day"],
                title=row["title"],
                badge_name=row["badge_name"],
                status=row["status"],
                quiz_score=row["quiz_score"],
                updated_at=row["updated_at"],
            )

    def get_progress_summary(self) -> Dict[str, Any]:
        """Return overall 5-day training progress and unlocked badges."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM training_milestones ORDER BY day ASC")
            rows = cursor.fetchall()

        milestones = [
            MilestoneRecord(
                day=r["day"],
                title=r["title"],
                badge_name=r["badge_name"],
                status=r["status"],
                quiz_score=r["quiz_score"],
                updated_at=r["updated_at"],
            ).model_dump()
            for r in rows
        ]
        completed = [m for m in milestones if m["status"] == "completed"]
        pct = round((len(completed) / max(len(milestones), 1)) * 100, 1)
        return {
            "total_days": len(milestones),
            "completed_days": len(completed),
            "completion_percentage": pct,
            "unlocked_badges": [m["badge_name"] for m in completed],
            "milestones": milestones,
        }

    def reset_all_progress(self) -> Dict[str, Any]:
        """Reset all training milestones to pending status (requires HITL approval)."""
        now = datetime.now(timezone.utc).isoformat()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE training_milestones SET status = 'pending', quiz_score = 0, updated_at = ?",
                (now,),
            )
            conn.commit()
        return self.get_progress_summary()

    def append_session_turn(self, session_id: str, role: str, content: str) -> None:
        """Persist a PII-scrubbed conversational turn in SQLite."""
        now = datetime.now(timezone.utc).isoformat()
        clean_content = PIIRedactor.redact(content)
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO session_history (session_id, role, content, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (session_id, role, clean_content, now),
            )
            conn.commit()

    def get_session_turns(self, session_id: str, limit: int = 20) -> List[Dict[str, str]]:
        """Retrieve persisted conversation history for a session."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT role, content, created_at
                FROM session_history
                WHERE session_id = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (session_id, limit),
            )
            rows = list(reversed(cursor.fetchall()))
        return [
            {"role": r["role"], "content": r["content"], "created_at": r["created_at"]}
            for r in rows
        ]


db = DatabaseManager()
