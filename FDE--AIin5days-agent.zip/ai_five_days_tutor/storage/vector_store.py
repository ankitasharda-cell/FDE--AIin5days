"""Persistent Vector Store using ChromaDB and optional Vertex AI Search for curriculum RAG."""

from dataclasses import dataclass
import logging
import os
import re
from typing import Any, Dict, List, Optional

from ai_five_days_tutor.config import settings
from ai_five_days_tutor.telemetry.tracer import PIIRedactor

logger = logging.getLogger("ai_five_days_tutor.vector_store")

try:
    import chromadb  # type: ignore
    from chromadb.config import Settings as ChromaSettings  # type: ignore

    HAS_CHROMADB = True
except ImportError:
    HAS_CHROMADB = False


@dataclass
class KnowledgeChunk:
    """Represents a retrieved curriculum knowledge chunk with citation metadata."""

    chunk_id: str
    title: str
    day: int
    section: str
    content: str
    anchor_url: str
    similarity_score: float


DEFAULT_KNOWLEDGE_CHUNKS: List[Dict[str, Any]] = [
    {
        "chunk_id": "day1_react_loop",
        "title": "Day 1: Agentic ReAct Loop & Prompt Constitution",
        "day": 1,
        "section": "ReAct Architecture",
        "content": (
            "The ReAct (Reason + Act) loop alternates between Thought, Action (tool call), "
            "and Observation (tool output). A production system prompt constitution defines "
            "Identity, Operational Workflow, Guardrails, and Output Contract."
        ),
        "anchor_url": "https://google.github.io/adk-docs/#day-1-foundations",
    },
    {
        "chunk_id": "day2_tools_schemas",
        "title": "Day 2: Tool Design, Pydantic Schemas & Guided Recovery",
        "day": 2,
        "section": "Tool & Interface Design",
        "content": (
            "Tools must include comprehensive docstrings, specific verb-noun names, strict "
            "Pydantic JSON schemas, and structured error returns with recovery_guidance so "
            "the LLM can self-correct without crashing."
        ),
        "anchor_url": "https://google.github.io/adk-docs/#day-2-tools-and-mcp",
    },
    {
        "chunk_id": "day3_context_compaction",
        "title": "Day 3: Context Engineering, Compaction & Progressive Disclosure",
        "day": 3,
        "section": "Context & Memory",
        "content": (
            "Prevent context bloat using sliding windows, token-based history compaction, "
            "Vertex AI context caching, persistent SQLite/ChromaDB session state, and "
            "progressive disclosure via modular SKILL.md files."
        ),
        "anchor_url": "https://google.github.io/adk-docs/#day-3-context-and-memory",
    },
    {
        "chunk_id": "day4_multi_agent_adk",
        "title": "Day 4: Multi-Agent Orchestration & Strategic Model Routing",
        "day": 4,
        "section": "Orchestration & Logic",
        "content": (
            "Decompose complex workflows using Coordinator/Supervisor and SequentialAgent "
            "patterns in Google ADK. Route latency-sensitive triage to gemini-2.5-flash and "
            "deep reasoning or rubric evaluation to gemini-2.5-pro."
        ),
        "anchor_url": "https://google.github.io/adk-docs/#day-4-multi-agent-orchestration",
    },
    {
        "chunk_id": "day5_observability_cicd",
        "title": "Day 5: OpenTelemetry Tracing, PII Redaction, IaC & Golden Evals",
        "day": 5,
        "section": "Observability & Infrastructure",
        "content": (
            "Production AgentOps requires structured JSON logging of pre-execution intent vs "
            "post-execution outcome, OpenTelemetry spans, PII redaction (Cloud DLP), "
            "Terraform IaC, Secret Manager, and automated golden-dataset regression tests."
        ),
        "anchor_url": "https://google.github.io/adk-docs/#day-5-agentops-and-eval",
    },
]


class VectorStoreManager:
    """Manages ChromaDB persistent vector storage, Vertex AI Search fallback, and semantic retrieval."""

    def __init__(
        self,
        persist_directory: Optional[str] = None,
        collection_name: str = "ai_five_days_curriculum",
    ) -> None:
        self.persist_directory = persist_directory or settings.chroma_persist_dir
        self.collection_name = collection_name
        self.memory_index: Dict[str, Dict[str, Any]] = {}
        self.client = None
        self.collection = None

        if HAS_CHROMADB:
            try:
                self.client = chromadb.PersistentClient(
                    path=self.persist_directory,
                    settings=ChromaSettings(anonymized_telemetry=False),
                )
                self.collection = self.client.get_or_create_collection(
                    name=self.collection_name,
                    metadata={"description": "AI in 5 Days Curriculum & AgentOps Knowledge Base"},
                )
            except Exception as exc:
                logger.debug("ChromaDB initialization fallback (%s)", exc)

        self.seed_default_knowledge()

    def seed_default_knowledge(self) -> int:
        """Index the default 5-day curriculum chunks into ChromaDB and memory store."""
        count = 0
        for item in DEFAULT_KNOWLEDGE_CHUNKS:
            self.index_chunk(
                chunk_id=item["chunk_id"],
                title=item["title"],
                day=item["day"],
                section=item["section"],
                content=item["content"],
                anchor_url=item["anchor_url"],
            )
            count += 1
        return count

    def index_chunk(
        self,
        chunk_id: str,
        title: str,
        day: int,
        section: str,
        content: str,
        anchor_url: str = "https://google.github.io/adk-docs/",
    ) -> str:
        """Add or update a PII-sanitized curriculum document chunk in the vector store."""
        clean_content = PIIRedactor.redact(content)
        meta = {
            "title": title,
            "day": int(day),
            "section": section,
            "anchor_url": anchor_url,
        }
        self.memory_index[chunk_id] = {"content": clean_content, "meta": meta}

        if HAS_CHROMADB and self.collection is not None:
            try:
                self.collection.upsert(
                    ids=[chunk_id],
                    documents=[clean_content],
                    metadatas=[meta],
                )
            except Exception as exc:
                logger.debug("Chroma upsert fallback (%s)", exc)
        return chunk_id

    def search(
        self,
        query: str,
        day: Optional[int] = None,
        top_k: int = 3,
    ) -> List[KnowledgeChunk]:
        """Retrieve relevant curriculum chunks via ChromaDB, Vertex AI Search, or lexical scoring."""
        vertex_datastore_id = os.getenv("VERTEX_AI_SEARCH_DATASTORE_ID")
        if vertex_datastore_id:
            vertex_hits = self._search_vertex_ai_datastore(query, vertex_datastore_id, top_k)
            if vertex_hits:
                return vertex_hits

        if HAS_CHROMADB and self.collection is not None and self.collection.count() > 0:
            try:
                where_filter = {"day": int(day)} if day is not None else None
                res = self.collection.query(
                    query_texts=[query],
                    n_results=min(top_k, self.collection.count()),
                    where=where_filter,
                    include=["documents", "metadatas", "distances"],
                )
                if res and res.get("ids") and res["ids"][0]:
                    chunks: List[KnowledgeChunk] = []
                    for idx, cid in enumerate(res["ids"][0]):
                        meta = res["metadatas"][0][idx]
                        dist = res["distances"][0][idx] if res.get("distances") else 0.2
                        score = max(0.05, round(1.0 - (dist / 2.0), 3))
                        chunks.append(
                            KnowledgeChunk(
                                chunk_id=cid,
                                title=str(meta.get("title", "Curriculum Guide")),
                                day=int(meta.get("day", 1)),
                                section=str(meta.get("section", "Overview")),
                                content=res["documents"][0][idx],
                                anchor_url=str(meta.get("anchor_url", "")),
                                similarity_score=score,
                            )
                        )
                    return chunks
            except Exception as exc:
                logger.debug("Chroma query fallback (%s)", exc)

        tokens = set(re.findall(r"[a-zA-Z0-9]+", query.lower()))
        scored: List[tuple[float, KnowledgeChunk]] = []
        for cid, entry in self.memory_index.items():
            meta = entry["meta"]
            if day is not None and int(meta["day"]) != int(day):
                continue
            haystack = f"{meta['title']} {meta['section']} {entry['content']}".lower()
            overlap = sum(2.0 for t in tokens if t in haystack)
            if overlap > 0 or not tokens:
                sim = min(1.0, round(max(overlap, 1.0) / max(len(tokens) * 2.0, 1.0), 3))
                scored.append(
                    (
                        overlap,
                        KnowledgeChunk(
                            chunk_id=cid,
                            title=meta["title"],
                            day=int(meta["day"]),
                            section=meta["section"],
                            content=entry["content"],
                            anchor_url=meta["anchor_url"],
                            similarity_score=sim,
                        ),
                    )
                )
        scored.sort(key=lambda item: item[0], reverse=True)
        return [item[1] for item in scored[:top_k]]

    def _search_vertex_ai_datastore(
        self, query: str, datastore_id: str, top_k: int
    ) -> List[KnowledgeChunk]:
        """Optional Vertex AI Search (Discovery Engine) retrieval connector."""
        try:
            from google.cloud import discoveryengine_v1 as discoveryengine  # type: ignore

            client = discoveryengine.SearchServiceClient()
            project_id = os.getenv("GOOGLE_CLOUD_PROJECT", "ai-in-5-days-project")
            serving_config = (
                f"projects/{project_id}/locations/global/collections/default_collection/"
                f"dataStores/{datastore_id}/servingConfigs/default_search"
            )
            request = discoveryengine.SearchRequest(
                serving_config=serving_config,
                query=query,
                page_size=top_k,
            )
            response = client.search(request)
            results: List[KnowledgeChunk] = []
            for idx, hit in enumerate(response.results):
                doc_data = dict(hit.document.derived_struct_data)
                results.append(
                    KnowledgeChunk(
                        chunk_id=hit.document.id or f"vertex_{idx}",
                        title=str(doc_data.get("title", "Vertex AI Search Result")),
                        day=1,
                        section="Vertex Knowledge",
                        content=str(doc_data.get("snippets", [query])[0]),
                        anchor_url=str(doc_data.get("link", "https://cloud.google.com/")),
                        similarity_score=0.95,
                    )
                )
            return results
        except Exception:
            return []


vector_store = VectorStoreManager()
