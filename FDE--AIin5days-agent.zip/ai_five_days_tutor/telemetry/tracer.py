"""Observability, OpenTelemetry distributed tracing, Intent-vs-Outcome JSON logging, and PII redaction."""

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import logging
import os
import re
import time
from typing import Any, Dict, List, Optional


# -----------------------------------------------------------------------------
# 1. PII Redaction Pipeline (Regex + Optional Google Cloud DLP API)
# -----------------------------------------------------------------------------
class PIIRedactor:
    """Scrubs sensitive PII and credentials before logging or persisting to storage."""

    PATTERNS = {
        "EMAIL": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
        "PHONE": re.compile(
            r"(?<!\d)(?:\+?1[-.\s]?)?(?:\(\d{3}\)|\d{3})[-.\s]\d{3}[-.\s]\d{4}(?!\d)"
        ),
        "SSN": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
        "API_KEY": re.compile(r"\b(?:AIza|ghp_|sk-|xoxb-)[A-Za-z0-9_\-]{12,}\b"),
        "IPV4": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
    }

    @classmethod
    def redact(cls, text: str, use_cloud_dlp: bool = False) -> str:
        """Redact sensitive PII tokens from a string using local patterns and optional Cloud DLP.

        Args:
            text (str): Raw text potentially containing sensitive user data.
            use_cloud_dlp (bool): Whether to additionally invoke Google Cloud DLP deidentify API.

        Returns:
            str: Sanitized string with sensitive patterns replaced by `[REDACTED_<TYPE>]`.
        """
        if not isinstance(text, str) or not text:
            return text

        sanitized = text
        for label, pattern in cls.PATTERNS.items():
            sanitized = pattern.sub(f"[REDACTED_{label}]", sanitized)

        if use_cloud_dlp:
            sanitized = cls._redact_via_cloud_dlp(sanitized)
        return sanitized

    @classmethod
    def _redact_via_cloud_dlp(cls, text: str) -> str:
        """Optional Google Cloud Data Loss Prevention (DLP) API de-identification."""
        try:
            from google.cloud import dlp_v2  # type: ignore

            dlp_client = dlp_v2.DlpServiceClient()
            project_id = os.getenv("GOOGLE_CLOUD_PROJECT", "ai-in-5-days-project")
            parent = f"projects/{project_id}"
            inspect_config = {
                "info_types": [
                    {"name": "EMAIL_ADDRESS"},
                    {"name": "PHONE_NUMBER"},
                    {"name": "US_SOCIAL_SECURITY_NUMBER"},
                ]
            }
            deidentify_config = {
                "info_type_transformations": {
                    "transformations": [
                        {
                            "primitive_transformation": {
                                "replace_with_info_type_config": {}
                            }
                        }
                    ]
                }
            }
            response = dlp_client.deidentify_content(
                request={
                    "parent": parent,
                    "inspect_config": inspect_config,
                    "deidentify_config": deidentify_config,
                    "item": {"value": text},
                }
            )
            return response.item.value
        except Exception:
            return text

    @classmethod
    def redact_dict(cls, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively scrub PII from dictionary values."""
        sanitized_dict: Dict[str, Any] = {}
        for key, value in payload.items():
            if isinstance(value, str):
                sanitized_dict[key] = cls.redact(value)
            elif isinstance(value, dict):
                sanitized_dict[key] = cls.redact_dict(value)
            elif isinstance(value, list):
                sanitized_dict[key] = [
                    cls.redact(item)
                    if isinstance(item, str)
                    else (cls.redact_dict(item) if isinstance(item, dict) else item)
                    for item in value
                ]
            else:
                sanitized_dict[key] = value
        return sanitized_dict


# -----------------------------------------------------------------------------
# 2. Structured JSON Logging Formatter
# -----------------------------------------------------------------------------
class StructuredJSONFormatter(logging.Formatter):
    """Formats standard Python log records into structured, PII-scrubbed JSON objects."""

    def format(self, record: logging.LogRecord) -> str:
        log_object: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "severity": record.levelname,
            "logger": record.name,
            "message": PIIRedactor.redact(record.getMessage()),
        }
        if hasattr(record, "structured_data") and isinstance(
            record.structured_data, dict
        ):
            log_object.update(PIIRedactor.redact_dict(record.structured_data))
        return json.dumps(log_object, ensure_ascii=False)


def configure_structured_logger(name: str = "ai_five_days_tutor.telemetry") -> logging.Logger:
    """Create and configure a structured JSON logger."""
    struct_logger = logging.getLogger(name)
    if not struct_logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(StructuredJSONFormatter())
        struct_logger.addHandler(handler)
        struct_logger.setLevel(logging.INFO)
        struct_logger.propagate = False
    return struct_logger


logger = configure_structured_logger()


# -----------------------------------------------------------------------------
# 3. OpenTelemetry Distributed Tracing Setup
# -----------------------------------------------------------------------------
try:
    from opentelemetry import trace  # type: ignore
    from opentelemetry.sdk.trace import TracerProvider  # type: ignore
    from opentelemetry.trace import Status, StatusCode  # type: ignore

    _provider = TracerProvider()
    trace.set_tracer_provider(_provider)
    otel_tracer = trace.get_tracer("ai_five_days_tutor.agent", "2.0.0")
    HAS_OTEL = True
except Exception:
    otel_tracer = None
    HAS_OTEL = False


# -----------------------------------------------------------------------------
# 4. Intent vs. Outcome Trace Records & Tracer
# -----------------------------------------------------------------------------
@dataclass
class ToolExecutionTrace:
    """Captures both the pre-execution intended action and post-execution actual outcome."""

    tool_name: str
    intended_action: str
    arguments: Dict[str, Any]
    actual_outcome: Any
    duration_ms: float
    status: str = "success"
    error_message: Optional[str] = None
    recovery_guidance: Optional[str] = None
    span_id: Optional[str] = None
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class TurnTrace:
    """End-to-end distributed trace record for an agent turn."""

    turn_id: str
    user_query: str
    routed_intent: str
    selected_model: str
    selected_subagent: str
    intended_plan: str
    agent_response: str
    tool_calls: List[ToolExecutionTrace] = field(default_factory=list)
    total_duration_ms: float = 0.0
    trace_id: Optional[str] = None
    pii_redacted: bool = True
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_json(self) -> str:
        """Serialize turn trace as a structured JSON log line with PII redaction."""
        payload = {
            "event": "agent_turn_completed",
            "turn_id": self.turn_id,
            "trace_id": self.trace_id or self.turn_id,
            "user_query": PIIRedactor.redact(self.user_query),
            "routed_intent": self.routed_intent,
            "selected_model": self.selected_model,
            "selected_subagent": self.selected_subagent,
            "intended_plan": PIIRedactor.redact(self.intended_plan),
            "actual_response_preview": PIIRedactor.redact(self.agent_response[:300]),
            "tool_calls": [
                {
                    "tool_name": tc.tool_name,
                    "intended_action": tc.intended_action,
                    "arguments": PIIRedactor.redact_dict(tc.arguments),
                    "actual_outcome_status": tc.status,
                    "duration_ms": tc.duration_ms,
                    "error_message": tc.error_message,
                    "recovery_guidance": tc.recovery_guidance,
                    "span_id": tc.span_id,
                }
                for tc in self.tool_calls
            ],
            "total_duration_ms": self.total_duration_ms,
            "pii_redacted": self.pii_redacted,
            "created_at": self.created_at,
        }
        return json.dumps(payload, ensure_ascii=False)


class AgentTelemetryTracer:
    """Manages OpenTelemetry spans and logs pre-execution Intent vs. post-execution Outcome."""

    def __init__(self) -> None:
        self.traces: List[TurnTrace] = []
        self.intent_outcome_logs: List[Dict[str, Any]] = []
        self._active_spans: Dict[str, Any] = {}

    def start_tool_trace(
        self,
        tool_name: str,
        args: Dict[str, Any],
        intended_action: Optional[str] = None,
    ) -> float:
        """Record the agent's intended action BEFORE tool execution and start an OTel span."""
        sanitized_args = PIIRedactor.redact_dict(args)
        intent_desc = (
            intended_action
            or f"Invoke '{tool_name}' with validated parameters to fulfill learner request."
        )
        span_key = f"{tool_name}:{time.perf_counter()}"

        if HAS_OTEL and otel_tracer is not None:
            try:
                span = otel_tracer.start_span(name=f"tool.{tool_name}")
                span.set_attribute("agent.tool.name", tool_name)
                span.set_attribute("agent.tool.intended_action", intent_desc)
                span.set_attribute("agent.tool.arguments", json.dumps(sanitized_args))
                self._active_spans[span_key] = span
            except Exception:
                pass

        intent_record = {
            "event": "tool_intent_before_execution",
            "tool_name": tool_name,
            "intended_action": intent_desc,
            "arguments": sanitized_args,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self.intent_outcome_logs.append(intent_record)
        logger.info(
            json.dumps(intent_record),
            extra={"structured_data": intent_record},
        )
        return time.perf_counter()

    def end_tool_trace(
        self,
        tool_name: str,
        args: Dict[str, Any],
        start_time: float,
        result: Any,
        intended_action: Optional[str] = None,
        error: Optional[Exception] = None,
        recovery_guidance: Optional[str] = None,
    ) -> ToolExecutionTrace:
        """Record the actual outcome AFTER tool execution and close the OpenTelemetry span."""
        duration_ms = round((time.perf_counter() - start_time) * 1000, 2)
        status = (
            "error"
            if error is not None
            or (isinstance(result, dict) and result.get("status") == "error")
            else "success"
        )
        error_msg = (
            str(error)
            if error
            else (
                result.get("error_message")
                if isinstance(result, dict)
                else None
            )
        )
        guidance = recovery_guidance or (
            result.get("recovery_guidance") if isinstance(result, dict) else None
        )
        intent_desc = (
            intended_action
            or f"Invoke '{tool_name}' with validated parameters to fulfill learner request."
        )
        span_id: Optional[str] = None

        if HAS_OTEL:
            try:
                for key in list(self._active_spans.keys()):
                    if key.startswith(f"{tool_name}:"):
                        span = self._active_spans.pop(key)
                        if hasattr(span, "get_span_context"):
                            span_id = format(span.get_span_context().span_id, "016x")
                        span.set_attribute("agent.tool.duration_ms", duration_ms)
                        span.set_attribute("agent.tool.actual_status", status)
                        if error is not None:
                            span.record_exception(error)
                            span.set_status(Status(StatusCode.ERROR, str(error)))
                        else:
                            span.set_status(Status(StatusCode.OK))
                        span.end()
                        break
            except Exception:
                pass

        sanitized_args = PIIRedactor.redact_dict(args)
        outcome_summary = PIIRedactor.redact(str(result)[:300]) if result is not None else "None"

        outcome_record = {
            "event": "tool_outcome_after_execution",
            "tool_name": tool_name,
            "intended_action": intent_desc,
            "actual_status": status,
            "actual_outcome_summary": outcome_summary,
            "duration_ms": duration_ms,
            "error_message": error_msg,
            "recovery_guidance": guidance,
            "span_id": span_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self.intent_outcome_logs.append(outcome_record)
        logger.info(
            json.dumps(outcome_record),
            extra={"structured_data": outcome_record},
        )

        return ToolExecutionTrace(
            tool_name=tool_name,
            intended_action=intent_desc,
            arguments=sanitized_args,
            actual_outcome=outcome_summary,
            duration_ms=duration_ms,
            status=status,
            error_message=error_msg,
            recovery_guidance=guidance,
            span_id=span_id,
        )

    def record_turn(self, turn_trace: TurnTrace) -> None:
        """Record a full conversational turn trace with root OpenTelemetry span."""
        if HAS_OTEL and otel_tracer is not None:
            try:
                with otel_tracer.start_as_current_span("agent.turn") as root_span:
                    root_span.set_attribute("agent.turn_id", turn_trace.turn_id)
                    root_span.set_attribute("agent.routed_intent", turn_trace.routed_intent)
                    root_span.set_attribute("agent.model", turn_trace.selected_model)
                    root_span.set_attribute("agent.subagent", turn_trace.selected_subagent)
                    root_span.set_attribute("agent.duration_ms", turn_trace.total_duration_ms)
                    if hasattr(root_span, "get_span_context"):
                        turn_trace.trace_id = format(
                            root_span.get_span_context().trace_id, "032x"
                        )
            except Exception:
                pass

        self.traces.append(turn_trace)
        logger.info(turn_trace.to_json())


tracer = AgentTelemetryTracer()
