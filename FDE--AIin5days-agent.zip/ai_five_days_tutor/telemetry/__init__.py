"""Telemetry package exposing OpenTelemetry tracer, structured JSON logger, and PII redactor."""

from ai_five_days_tutor.telemetry.tracer import (
    AgentTelemetryTracer,
    PIIRedactor,
    StructuredJSONFormatter,
    ToolExecutionTrace,
    TurnTrace,
    tracer,
)

__all__ = [
    "AgentTelemetryTracer",
    "PIIRedactor",
    "StructuredJSONFormatter",
    "ToolExecutionTrace",
    "TurnTrace",
    "tracer",
]
