"""Pydantic-validated tools with explicit JSON schemas, descriptive names, and guided error recovery."""

from typing import Any, Dict, List, Optional
import uuid

try:
    from pydantic import BaseModel, Field, ValidationError
except ImportError:
    from ai_five_days_tutor.pydantic_compat import BaseModel, Field, ValidationError

from ai_five_days_tutor.guardrails import hitl_gate
from ai_five_days_tutor.storage.async_worker import async_memory_worker
from ai_five_days_tutor.storage.database import db
from ai_five_days_tutor.storage.vector_store import vector_store
from ai_five_days_tutor.telemetry.tracer import tracer

CURRICULUM: Dict[int, Dict[str, Any]] = {
    1: {
        "title": "Day 1: Foundations of LLMs, Prompting & Agentic Thinking",
        "concepts": [
            "Single-turn LLM completions vs. the Agentic ReAct Loop (Thought -> Action -> Observation)",
            "The 4 Pillars of a System Prompt: Identity/Role, Operational Workflow, Explicit Guardrails, Output Contract",
            "Vibe Coding: Expressing clear intent, acceptance criteria, and verification constraints",
        ],
        "lab": (
            "Write a 'Strict Bug Triage & Root-Cause Analyst' system prompt that enforces "
            "an investigation protocol, an anti-hallucination missing-context rule, and a "
            "structured Markdown output contract."
        ),
        "badge": "Prompt Architect",
    },
    2: {
        "title": "Day 2: Extending Agents with Tools, Grounding & MCP",
        "concepts": [
            "How LLMs choose and invoke tools using JSON schemas, type hints, and docstrings",
            "Grounding responses in codebase search, file inspection, and documentation",
            "Connecting external tool servers via Model Context Protocol (MCP)",
        ],
        "lab": (
            "Implement a Python function tool with complete type annotations, a detailed "
            "docstring (Args/Returns), and structured error-handling dictionaries with recovery_guidance."
        ),
        "badge": "Toolsmith",
    },
    3: {
        "title": "Day 3: Context Engineering, Rules & Reusable Skills",
        "concepts": [
            "Context window hygiene, sliding-window compaction, and avoiding 'lost in the middle' bloat",
            "Always-on Rules (AGENTS.md) vs. On-Demand Skills (SKILL.md)",
            "Progressive Disclosure: Loading bulky reference manuals only when needed",
        ],
        "lab": (
            "Create a modular SKILL.md with YAML frontmatter (name, description with "
            "'Use when' / 'Don't use for' triggers) and a companion references/ doc."
        ),
        "badge": "Skill Author",
    },
    4: {
        "title": "Day 4: Multi-Agent Orchestration (Subagents & Google ADK)",
        "concepts": [
            "When to decompose into multiple agents: context isolation, parallel fan-out, Maker-Checker review",
            "Strategic Model Routing: Flash for fast intent routing vs. Pro for complex synthesis",
            "Building declarative workflows with Google ADK (LlmAgent, SequentialAgent, HITL hooks)",
        ],
        "lab": (
            "Build a 2-agent Maker-Checker pipeline where an Author agent drafts an "
            "output and an independent Reviewer agent verifies it against a rubric."
        ),
        "badge": "Orchestrator",
    },
    5: {
        "title": "Day 5: Agent Evaluation, Safety Guardrails & Capstone Project",
        "concepts": [
            "3-Layer Evaluation: Trajectory/tool assertions, LLM-as-a-Judge rubrics, side-by-side ablation",
            "Observability: OpenTelemetry distributed tracing, Intent-vs-Outcome JSON logging, and PII redaction",
            "Infrastructure & CI/CD: Terraform IaC, Google Cloud Secret Manager, and golden dataset pytest suites",
        ],
        "lab": (
            "Design, build, and evaluate a custom Capstone Agent tailored to your daily "
            "workflow with a golden evaluation dataset and Terraform deployment config."
        ),
        "badge": "Certified AI in Five Days Agent Engineer",
    },
}

QUIZZES: Dict[int, Dict[str, Any]] = {
    1: {
        "question": (
            "In an agentic ReAct loop, what happens immediately after the agent executes "
            "a tool (Action)?"
        ),
        "options": {
            "A": "It receives an Observation (the tool output/error) and feeds it into the next Thought step.",
            "B": "It immediately terminates and returns raw JSON to the user.",
            "C": "It clears its context window and restarts from scratch.",
        },
        "correct_option": "A",
        "explanation": (
            "In the ReAct (Reason + Act) loop, tool outputs become Observations that "
            "allow the model to verify results or self-correct on the next reasoning step."
        ),
    },
    2: {
        "question": (
            "How does an LLM know when to invoke a specific Python function tool and "
            "what arguments to pass?"
        ),
        "options": {
            "A": "By reading the function's name, docstring, and parameter JSON schema.",
            "B": "By decompiling the Python bytecode at runtime.",
            "C": "By guessing random parameter names until a call succeeds.",
        },
        "correct_option": "A",
        "explanation": (
            "ADK and MCP inspect the function signature, Pydantic schema, and docstring to "
            "generate the JSON schema that guides the LLM's tool calls."
        ),
    },
    3: {
        "question": (
            "Why should multi-step domain runbooks be placed in a Skill (SKILL.md) "
            "rather than an always-on Rule?"
        ),
        "options": {
            "A": "Skills use progressive disclosure—only their name and description are loaded at rest, saving context tokens.",
            "B": "Rules do not support Markdown formatting.",
            "C": "Skills execute automatically without any user prompt.",
        },
        "correct_option": "A",
        "explanation": (
            "Progressive disclosure keeps the base prompt fast and focused, loading "
            "detailed instructions only when the user's task matches the skill description."
        ),
    },
    4: {
        "question": (
            "What is the primary architectural benefit of delegating a broad search "
            "task to a subagent?"
        ),
        "options": {
            "A": "Context isolation—the subagent absorbs noisy intermediate search results and returns a concise summary.",
            "B": "Subagents bypass all permission and security checks.",
            "C": "Subagents run without using any model tokens.",
        },
        "correct_option": "A",
        "explanation": (
            "Isolating heavy exploratory work in a subagent prevents intermediate tool "
            "outputs from polluting the coordinator agent's context window."
        ),
    },
    5: {
        "question": (
            "When configuring tools for a read-only code reviewer subagent, which "
            "principle should guide your tool allowlist?"
        ),
        "options": {
            "A": "Least privilege—grant only read/search tools and omit file-mutation tools.",
            "B": "Grant all available write and shell tools just in case.",
            "C": "Disable all tools so the reviewer cannot read files.",
        },
        "correct_option": "A",
        "explanation": (
            "Enforcing least-privilege tool access guarantees a review or research "
            "agent cannot accidentally mutate files or trigger unintended side effects."
        ),
    },
}


# -----------------------------------------------------------------------------
# Explicit Pydantic Input & Output JSON Schemas
# -----------------------------------------------------------------------------
class CurriculumLookupInput(BaseModel):
    """Input schema for retrieving a daily training module."""

    day: int = Field(
        ...,
        ge=1,
        le=5,
        description="The training day number (must be an integer between 1 and 5).",
    )


class CurriculumLookupOutput(BaseModel):
    """Output schema for a daily curriculum lookup."""

    status: str
    day: Optional[int] = None
    title: Optional[str] = None
    concepts: List[str] = Field(default_factory=list)
    lab: Optional[str] = None
    badge: Optional[str] = None
    error_message: Optional[str] = None
    recovery_guidance: Optional[str] = None


class SearchKnowledgeInput(BaseModel):
    """Input schema for semantic RAG search over the curriculum knowledge base."""

    query: str = Field(
        ...,
        min_length=2,
        description="Technical or conceptual search query (at least 2 characters).",
    )
    day: Optional[int] = Field(
        default=None,
        ge=1,
        le=5,
        description="Optional training day filter (1 to 5).",
    )
    top_k: int = Field(
        default=3,
        ge=1,
        le=10,
        description="Maximum number of relevant chunks to retrieve (1 to 10).",
    )


class SearchKnowledgeOutput(BaseModel):
    """Output schema for curriculum vector search."""

    status: str
    query: str
    total_matches: int = 0
    matches: List[Dict[str, Any]] = Field(default_factory=list)
    error_message: Optional[str] = None
    recovery_guidance: Optional[str] = None


class QuizEvaluationInput(BaseModel):
    """Input schema for grading a learner's daily quiz response."""

    day: int = Field(
        ...,
        ge=1,
        le=5,
        description="The training day number (1 through 5).",
    )
    selected_option: str = Field(
        ...,
        pattern=r"^[AaBbCc]$",
        description="The learner's chosen option letter ('A', 'B', or 'C').",
    )


class SaveStudyNoteInput(BaseModel):
    """Input schema for persisting a learner study note."""

    title: str = Field(
        ...,
        min_length=3,
        max_length=120,
        description="Short descriptive title for the study note (3 to 120 chars).",
    )
    content: str = Field(
        ...,
        min_length=5,
        description="Detailed note content (automatically scrubbed for PII before storage).",
    )
    day: int = Field(
        default=1,
        ge=1,
        le=5,
        description="Associated training day number (1 to 5).",
    )
    tags: Optional[List[str]] = Field(
        default=None,
        description="Optional list of topic tags (e.g., ['adk', 'guardrails']).",
    )


class ResetProgressInput(BaseModel):
    """Input schema for resetting all learner training progress (protected by HITL hook)."""

    confirm_human_approval: bool = Field(
        default=False,
        description="Explicit human confirmation flag required by the HITL guardrail.",
    )


CURRICULUM_LOOKUP_SCHEMA = CurriculumLookupInput.model_json_schema()
SEARCH_KNOWLEDGE_SCHEMA = SearchKnowledgeInput.model_json_schema()
QUIZ_EVALUATION_SCHEMA = QuizEvaluationInput.model_json_schema()
SAVE_STUDY_NOTE_SCHEMA = SaveStudyNoteInput.model_json_schema()
RESET_PROGRESS_SCHEMA = ResetProgressInput.model_json_schema()


# -----------------------------------------------------------------------------
# Tool Implementations with Guided Error Recovery & Telemetry Spans
# -----------------------------------------------------------------------------
def retrieve_daily_curriculum_module(day: int) -> Dict[str, Any]:
    """Retrieve the lesson plan, core concepts, hands-on lab, and badge for a training day (1 to 5).

    Args:
        day (int): The training day number (must be between 1 and 5).

    Returns:
        Dict[str, Any]: Structured dictionary validated by CurriculumLookupOutput containing
            status, day, title, concepts, lab, badge, and optional recovery_guidance.
    """
    raw_args = {"day": day}
    intent = f"Retrieve curriculum concepts and hands-on lab for Day {day}."
    start_time = tracer.start_tool_trace("retrieve_daily_curriculum_module", raw_args, intent)

    try:
        validated = CurriculumLookupInput(day=day)
    except ValidationError as exc:
        guidance = (
            f"Invalid day '{day}'. Please pass an integer between 1 and 5 "
            "(1=Foundations, 2=Tools/MCP, 3=Context/Skills, 4=Multi-Agent ADK, 5=Eval/AgentOps)."
        )
        output = CurriculumLookupOutput(
            status="error",
            error_message=f"Invalid day {day}. Please choose a day between 1 and 5.",
            recovery_guidance=guidance,
        ).model_dump()
        tracer.end_tool_trace(
            "retrieve_daily_curriculum_module",
            raw_args,
            start_time,
            output,
            intended_action=intent,
            error=exc,
            recovery_guidance=guidance,
        )
        return output

    module_data = CURRICULUM[validated.day]
    output = CurriculumLookupOutput(
        status="success",
        day=validated.day,
        title=module_data["title"],
        concepts=module_data["concepts"],
        lab=module_data["lab"],
        badge=module_data["badge"],
    ).model_dump()
    tracer.end_tool_trace(
        "retrieve_daily_curriculum_module", raw_args, start_time, output, intended_action=intent
    )
    return output


def search_curriculum_knowledge_base(
    query: str, day: Optional[int] = None, top_k: int = 3
) -> Dict[str, Any]:
    """Search the ChromaDB curriculum vector store for grounded AgentOps concepts and citations.

    Args:
        query (str): The conceptual or technical question to search (minimum 2 characters).
        day (Optional[int]): Optional training day filter (1 to 5). Defaults to None.
        top_k (int): Maximum number of matching sections to return (1 to 10). Defaults to 3.

    Returns:
        Dict[str, Any]: Structured dictionary validated by SearchKnowledgeOutput with matching
            chunks, similarity scores, anchor URLs, and recovery_guidance if empty.
    """
    raw_args = {"query": query, "day": day, "top_k": top_k}
    intent = f"Search curriculum vector database for query='{query}' (day={day})."
    start_time = tracer.start_tool_trace("search_curriculum_knowledge_base", raw_args, intent)

    try:
        validated = SearchKnowledgeInput(query=query, day=day, top_k=top_k)
    except ValidationError as exc:
        guidance = (
            "Ensure 'query' has at least 2 characters, 'day' is between 1 and 5 (or None), "
            "and 'top_k' is between 1 and 10."
        )
        output = SearchKnowledgeOutput(
            status="error",
            query=str(query),
            error_message=str(exc),
            recovery_guidance=guidance,
        ).model_dump()
        tracer.end_tool_trace(
            "search_curriculum_knowledge_base",
            raw_args,
            start_time,
            output,
            intended_action=intent,
            error=exc,
            recovery_guidance=guidance,
        )
        return output

    hits = vector_store.search(
        query=validated.query, day=validated.day, top_k=validated.top_k
    )
    if not hits:
        guidance = (
            f"No curriculum chunks matched '{validated.query}'. Try removing the day filter "
            "or searching broader keywords such as 'ReAct', 'Pydantic', 'compaction', 'ADK', or 'OpenTelemetry'."
        )
        output = SearchKnowledgeOutput(
            status="not_found",
            query=validated.query,
            total_matches=0,
            matches=[],
            recovery_guidance=guidance,
        ).model_dump()
        tracer.end_tool_trace(
            "search_curriculum_knowledge_base",
            raw_args,
            start_time,
            output,
            intended_action=intent,
            recovery_guidance=guidance,
        )
        return output

    formatted = [
        {
            "chunk_id": h.chunk_id,
            "title": h.title,
            "day": h.day,
            "section": h.section,
            "content": h.content,
            "anchor_url": h.anchor_url,
            "similarity_score": h.similarity_score,
        }
        for h in hits
    ]
    output = SearchKnowledgeOutput(
        status="success",
        query=validated.query,
        total_matches=len(formatted),
        matches=formatted,
    ).model_dump()
    tracer.end_tool_trace(
        "search_curriculum_knowledge_base", raw_args, start_time, output, intended_action=intent
    )
    return output


def administer_daily_knowledge_quiz(day: int) -> Dict[str, Any]:
    """Retrieve the multiple-choice knowledge check question for a training day (1 to 5).

    Args:
        day (int): The training day number (1 through 5).

    Returns:
        Dict[str, Any]: Dictionary containing the quiz question, options A/B/C, or recovery_guidance.
    """
    raw_args = {"day": day}
    intent = f"Fetch multiple-choice knowledge check question for Day {day}."
    start_time = tracer.start_tool_trace("administer_daily_knowledge_quiz", raw_args, intent)

    try:
        validated = CurriculumLookupInput(day=day)
    except ValidationError as exc:
        guidance = "Pass a valid integer day between 1 and 5 to retrieve the daily quiz."
        output = {
            "status": "error",
            "error_message": f"Invalid day {day}. Please choose a day between 1 and 5.",
            "recovery_guidance": guidance,
        }
        tracer.end_tool_trace(
            "administer_daily_knowledge_quiz",
            raw_args,
            start_time,
            output,
            intended_action=intent,
            error=exc,
            recovery_guidance=guidance,
        )
        return output

    quiz = QUIZZES[validated.day]
    output = {
        "status": "success",
        "day": validated.day,
        "question": quiz["question"],
        "options": quiz["options"],
    }
    tracer.end_tool_trace(
        "administer_daily_knowledge_quiz", raw_args, start_time, output, intended_action=intent
    )
    return output


def evaluate_learner_quiz_submission(day: int, selected_option: str) -> Dict[str, Any]:
    """Grade a learner's quiz submission ('A', 'B', or 'C'), persist milestone progress, and award badges.

    Args:
        day (int): The training day number (1 through 5).
        selected_option (str): The learner's selected option letter ('A', 'B', or 'C').

    Returns:
        Dict[str, Any]: Grading result with is_correct, explanation, badge_unlocked, and recovery_guidance.
    """
    raw_args = {"day": day, "selected_option": selected_option}
    intent = f"Evaluate learner quiz answer '{selected_option}' for Day {day} and update milestone state."
    start_time = tracer.start_tool_trace("evaluate_learner_quiz_submission", raw_args, intent)

    normalized_opt = (selected_option or "").strip().upper()[:1]
    try:
        validated = QuizEvaluationInput(day=day, selected_option=normalized_opt)
    except ValidationError as exc:
        guidance = (
            "Ensure 'day' is an integer between 1 and 5 and 'selected_option' is one of 'A', 'B', or 'C'."
        )
        output = {
            "status": "error",
            "error_message": f"Invalid quiz submission parameters (day={day}, selected_option={selected_option}).",
            "recovery_guidance": guidance,
        }
        tracer.end_tool_trace(
            "evaluate_learner_quiz_submission",
            raw_args,
            start_time,
            output,
            intended_action=intent,
            error=exc,
            recovery_guidance=guidance,
        )
        return output

    quiz = QUIZZES[validated.day]
    is_correct = validated.selected_option == quiz["correct_option"]
    badge_unlocked = CURRICULUM[validated.day]["badge"] if is_correct else None

    if is_correct:
        db.update_milestone(day=validated.day, status="completed", quiz_score=100)

    output = {
        "status": "success",
        "day": validated.day,
        "selected_option": validated.selected_option,
        "is_correct": is_correct,
        "correct_option": quiz["correct_option"],
        "explanation": quiz["explanation"],
        "badge_unlocked": badge_unlocked,
    }
    tracer.end_tool_trace(
        "evaluate_learner_quiz_submission", raw_args, start_time, output, intended_action=intent
    )
    return output


def record_learner_study_note(
    title: str,
    content: str,
    day: int = 1,
    tags: Optional[List[str]] = None,
    run_async: bool = False,
) -> Dict[str, Any]:
    """Save a PII-redacted learner study note into SQLite and index it into ChromaDB.

    Args:
        title (str): Short title for the note (3 to 120 characters).
        content (str): Detailed study note or takeaway text (minimum 5 characters).
        day (int): Training day number (1 to 5). Defaults to 1.
        tags (Optional[List[str]]): Optional list of topic tags. Defaults to None.
        run_async (bool): If True, dispatches storage/indexing to AsyncMemoryWorker in the background.

    Returns:
        Dict[str, Any]: Confirmation dictionary with persisted note metadata or recovery_guidance.
    """
    raw_args = {"title": title, "content": content, "day": day, "tags": tags, "run_async": run_async}
    intent = f"Persist learner study note '{title}' for Day {day} with PII scrubbing."
    start_time = tracer.start_tool_trace("record_learner_study_note", raw_args, intent)

    try:
        validated = SaveStudyNoteInput(title=title, content=content, day=day, tags=tags)
    except ValidationError as exc:
        guidance = (
            "Provide a 'title' between 3 and 120 characters, 'content' of at least 5 characters, "
            "and 'day' between 1 and 5."
        )
        output = {
            "status": "error",
            "error_message": str(exc),
            "recovery_guidance": guidance,
        }
        tracer.end_tool_trace(
            "record_learner_study_note",
            raw_args,
            start_time,
            output,
            intended_action=intent,
            error=exc,
            recovery_guidance=guidance,
        )
        return output

    if run_async:
        future = async_memory_worker.submit_background_note_persistence(
            title=validated.title,
            content=validated.content,
            day=validated.day,
            tags=validated.tags,
        )
        note_data = future.result(timeout=5.0)
    else:
        record = db.save_study_note(
            title=validated.title,
            content=validated.content,
            day=validated.day,
            tags=validated.tags,
        )
        vector_store.index_chunk(
            chunk_id=f"user_note_{record.id}",
            title=record.title,
            day=record.day,
            section="Learner Study Note",
            content=record.content,
        )
        note_data = record.model_dump()

    output = {
        "status": "success",
        "note": note_data,
        "message": f"Saved study note '{note_data['title']}' for Day {validated.day}.",
    }
    tracer.end_tool_trace(
        "record_learner_study_note", raw_args, start_time, output, intended_action=intent
    )
    return output


def query_learner_study_notes(
    query: str = "", day: Optional[int] = None
) -> Dict[str, Any]:
    """Query persisted learner study notes from SQLite by keyword and optional day filter.

    Args:
        query (str): Keyword filter to search across note titles, content, and tags.
        day (Optional[int]): Optional training day filter (1 to 5).

    Returns:
        Dict[str, Any]: Dictionary containing count and list of matching study notes.
    """
    raw_args = {"query": query, "day": day}
    intent = f"Query persisted learner study notes matching '{query}' (day={day})."
    start_time = tracer.start_tool_trace("query_learner_study_notes", raw_args, intent)

    notes = [n.model_dump() for n in db.query_study_notes(query=query, day=day)]
    output = {
        "status": "success",
        "count": len(notes),
        "notes": notes,
    }
    tracer.end_tool_trace(
        "query_learner_study_notes", raw_args, start_time, output, intended_action=intent
    )
    return output


def get_learner_training_progress() -> Dict[str, Any]:
    """Retrieve the learner's 5-day training completion percentage, milestones, and unlocked badges.

    Returns:
        Dict[str, Any]: Progress summary dictionary from SQLite.
    """
    raw_args: Dict[str, Any] = {}
    intent = "Retrieve learner's 5-day milestone completion status and unlocked badges."
    start_time = tracer.start_tool_trace("get_learner_training_progress", raw_args, intent)

    summary = db.get_progress_summary()
    output = {"status": "success", **summary}
    tracer.end_tool_trace(
        "get_learner_training_progress", raw_args, start_time, output, intended_action=intent
    )
    return output


def reset_learner_training_progress(
    confirm_human_approval: bool = False,
) -> Dict[str, Any]:
    """Reset all 5-day training milestones to pending status (guarded by Human-in-the-Loop hook).

    Args:
        confirm_human_approval (bool): Must be set to True after explicit human confirmation.

    Returns:
        Dict[str, Any]: Reset confirmation or a HITL approval gate prompt with recovery_guidance.
    """
    raw_args = {"confirm_human_approval": confirm_human_approval}
    intent = "Reset all learner training milestones (high-stakes state mutation)."
    start_time = tracer.start_tool_trace("reset_learner_training_progress", raw_args, intent)

    if hitl_gate.requires_approval("reset_learner_training_progress", raw_args):
        approval = hitl_gate.create_approval_request(
            request_id=str(uuid.uuid4()),
            action_name="reset_learner_training_progress",
            params=raw_args,
        )
        tracer.end_tool_trace(
            "reset_learner_training_progress",
            raw_args,
            start_time,
            approval,
            intended_action=intent,
            recovery_guidance=approval["recovery_guidance"],
        )
        return approval

    summary = db.reset_all_progress()
    output = {
        "status": "success",
        "message": "All 5-day training milestones have been reset with human approval.",
        "progress": summary,
    }
    tracer.end_tool_trace(
        "reset_learner_training_progress", raw_args, start_time, output, intended_action=intent
    )
    return output


# Backwards-compatible aliases
get_daily_curriculum = retrieve_daily_curriculum_module
get_daily_quiz = administer_daily_knowledge_quiz
grade_quiz_answer = evaluate_learner_quiz_submission

ALL_TUTOR_TOOLS = [
    retrieve_daily_curriculum_module,
    search_curriculum_knowledge_base,
    administer_daily_knowledge_quiz,
    evaluate_learner_quiz_submission,
    record_learner_study_note,
    query_learner_study_notes,
    get_learner_training_progress,
    reset_learner_training_progress,
]
