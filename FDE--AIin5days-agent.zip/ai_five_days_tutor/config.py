"""Typed configuration management with Google Cloud Secret Manager and Pydantic Settings."""

import os
from pathlib import Path
from typing import Optional

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict  # type: ignore

    class Settings(BaseSettings):
        """Application configuration loaded from environment variables and Secret Manager."""

        model_config = SettingsConfigDict(
            env_file=".env",
            env_file_encoding="utf-8",
            extra="ignore",
        )

        gemini_api_key: Optional[str] = None
        fast_model: str = "gemini-2.5-flash"
        reasoning_model: str = "gemini-2.5-pro"
        embedding_model: str = "text-embedding-004"
        sqlite_db_path: str = "./data/tutor_state.db"
        chroma_persist_dir: str = "./data/chroma_db"
        max_history_turns: int = 8
        max_context_tokens: int = 4000
        log_level: str = "INFO"
        enable_telemetry: bool = True
        enable_cloud_dlp: bool = False

        def ensure_directories(self) -> None:
            """Create runtime persistence directories if they do not exist."""
            Path(self.sqlite_db_path).parent.mkdir(parents=True, exist_ok=True)
            Path(self.chroma_persist_dir).mkdir(parents=True, exist_ok=True)

    settings = Settings()

except ImportError:

    class SettingsFallback:
        """Fallback settings loader when pydantic-settings is not installed."""

        def __init__(self) -> None:
            self.gemini_api_key: Optional[str] = os.getenv("GEMINI_API_KEY")
            self.fast_model: str = os.getenv("FAST_MODEL", "gemini-2.5-flash")
            self.reasoning_model: str = os.getenv("REASONING_MODEL", "gemini-2.5-pro")
            self.embedding_model: str = os.getenv("EMBEDDING_MODEL", "text-embedding-004")
            self.sqlite_db_path: str = os.getenv("SQLITE_DB_PATH", "./data/tutor_state.db")
            self.chroma_persist_dir: str = os.getenv("CHROMA_PERSIST_DIR", "./data/chroma_db")
            self.max_history_turns: int = int(os.getenv("MAX_HISTORY_TURNS", "8"))
            self.max_context_tokens: int = int(os.getenv("MAX_CONTEXT_TOKENS", "4000"))
            self.log_level: str = os.getenv("LOG_LEVEL", "INFO")
            self.enable_telemetry: bool = os.getenv("ENABLE_TELEMETRY", "true").lower() == "true"
            self.enable_cloud_dlp: bool = os.getenv("ENABLE_CLOUD_DLP", "false").lower() == "true"

        def ensure_directories(self) -> None:
            """Create runtime persistence directories if they do not exist."""
            Path(self.sqlite_db_path).parent.mkdir(parents=True, exist_ok=True)
            Path(self.chroma_persist_dir).mkdir(parents=True, exist_ok=True)

    settings = SettingsFallback()  # type: ignore

if not settings.gemini_api_key:
    from ai_five_days_tutor.storage.secret_manager import secret_client

    settings.gemini_api_key = secret_client.get_secret(
        secret_id="ai-five-days-gemini-key",
        fallback_env="GEMINI_API_KEY",
    )

settings.ensure_directories()
