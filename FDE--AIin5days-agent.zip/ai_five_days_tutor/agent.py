"""AI in Five Days — Multi-Agent Tutor built with Google ADK (Coordinator + Specialist Subagents)."""

from typing import Any, Dict, Optional

from ai_five_days_tutor.config import settings
from ai_five_days_tutor.guardrails import hitl_gate, input_guardrail, output_guardrail
from ai_five_days_tutor.multi_agent import AIFiveDaysTutorOrchestrator, tutor_orchestrator
from ai_five_days_tutor.prompts import TUTOR_CONSTITUTION_SYSTEM_PROMPT
from ai_five_days_tutor.tools.curriculum_tools import (
    ALL_TUTOR_TOOLS,
    CURRICULUM,
    QUIZZES,
    administer_daily_knowledge_quiz,
    evaluate_learner_quiz_submission,
    get_daily_curriculum,
    get_daily_quiz,
    get_learner_training_progress,
    grade_quiz_answer,
    query_learner_study_notes,
    record_learner_study_note,
    reset_learner_training_progress,
    retrieve_daily_curriculum_module,
    search_curriculum_knowledge_base,
)


# -----------------------------------------------------------------------------
# ADK Guardrail & HITL Lifecycle Callbacks
# -----------------------------------------------------------------------------
def adk_before_model_guardrail(
    callback_context: Any, llm_request: Any
) -> Optional[Dict[str, Any]]:
    """ADK before_model_callback enforcing prompt-injection safety and PII scrubbing."""
    raw_text = str(getattr(llm_request, "contents", ""))
    eval_res = input_guardrail.validate(raw_text)
    if not eval_res.passed:
        return {"status": "blocked", "reason": eval_res.reason}
    return None


def adk_before_tool_hitl_hook(
    tool: Any, args: Dict[str, Any], tool_context: Any
) -> Optional[Dict[str, Any]]:
    """ADK before_tool_callback enforcing Human-in-the-Loop confirmation on high-stakes tools."""
    tool_name = getattr(tool, "name", str(tool))
    if hitl_gate.requires_approval(tool_name, args):
        return hitl_gate.create_approval_request(
            request_id="adk_hitl_gate",
            action_name=tool_name,
            params=args,
        )
    return None


# -----------------------------------------------------------------------------
# Google ADK Multi-Agent Hierarchy (Coordinator + Specialist Subagents)
# -----------------------------------------------------------------------------
try:
    from google.adk.agents import Agent, LlmAgent, SequentialAgent  # type: ignore

    curriculum_research_agent = LlmAgent(
        model=settings.fast_model,
        name="curriculum_research_agent",
        description=(
            "Specialist subagent for retrieving daily curriculum modules (Days 1-5) "
            "and searching the ChromaDB AgentOps knowledge base with citations."
        ),
        instruction=(
            "You are the Curriculum & RAG Specialist. Use `retrieve_daily_curriculum_module` "
            "and `search_curriculum_knowledge_base` to deliver grounded explanations with "
            "source links."
        ),
        tools=[retrieve_daily_curriculum_module, search_curriculum_knowledge_base],
    )

    assessment_grader_agent = LlmAgent(
        model=settings.fast_model,
        name="assessment_grader_agent",
        description=(
            "Specialist subagent for administering daily knowledge quizzes, grading learner "
            "answers, and managing 5-day milestone badges."
        ),
        instruction=(
            "You are the Assessment & Badge Grader. Use `administer_daily_knowledge_quiz`, "
            "`evaluate_learner_quiz_submission`, `get_learner_training_progress`, and "
            "`reset_learner_training_progress` (only with explicit human confirmation)."
        ),
        tools=[
            administer_daily_knowledge_quiz,
            evaluate_learner_quiz_submission,
            get_learner_training_progress,
            reset_learner_training_progress,
        ],
    )

    study_notes_agent = LlmAgent(
        model=settings.fast_model,
        name="study_notes_agent",
        description=(
            "Specialist subagent for persisting PII-redacted learner study notes into SQLite "
            "and ChromaDB via the non-blocking AsyncMemoryWorker."
        ),
        instruction=(
            "You are the Study Notes & Memory Specialist. Use `record_learner_study_note` "
            "and `query_learner_study_notes` to save and retrieve learner takeaways."
        ),
        tools=[record_learner_study_note, query_learner_study_notes],
    )

    capstone_architect_agent = LlmAgent(
        model=settings.reasoning_model,
        name="capstone_architect_agent",
        description=(
            "Deep-reasoning specialist subagent powered by Gemini Pro for designing and "
            "reviewing 95-point AgentOps capstone architectures."
        ),
        instruction=(
            "You are the Principal AgentOps Capstone Architect. Guide learners in designing "
            "multi-agent systems that satisfy all 5 pillars of the 95-point rubric."
        ),
        tools=[search_curriculum_knowledge_base, get_learner_training_progress],
    )

    sequential_daily_learning_pipeline = SequentialAgent(
        name="sequential_daily_learning_pipeline",
        description="Executes Concept Research followed by Quiz Assessment in sequence.",
        sub_agents=[curriculum_research_agent, assessment_grader_agent],
    )

    root_agent = Agent(
        model=settings.fast_model,
        name="ai_five_days_tutor",
        description=(
            "Coordinator Agent for the AI in Five Days training curriculum, orchestrating "
            "specialist subagents with strategic model routing, HITL hooks, and OTel tracing."
        ),
        instruction=TUTOR_CONSTITUTION_SYSTEM_PROMPT,
        tools=ALL_TUTOR_TOOLS,
        sub_agents=[
            curriculum_research_agent,
            assessment_grader_agent,
            study_notes_agent,
            capstone_architect_agent,
        ],
    )

except Exception:
    # Graceful fallback when google-adk is not installed in lightweight test environments
    root_agent = tutor_orchestrator  # type: ignore

__all__ = [
    "AIFiveDaysTutorOrchestrator",
    "ALL_TUTOR_TOOLS",
    "CURRICULUM",
    "QUIZZES",
    "administer_daily_knowledge_quiz",
    "evaluate_learner_quiz_submission",
    "get_daily_curriculum",
    "get_daily_quiz",
    "get_learner_training_progress",
    "grade_quiz_answer",
    "query_learner_study_notes",
    "record_learner_study_note",
    "reset_learner_training_progress",
    "retrieve_daily_curriculum_module",
    "root_agent",
    "search_curriculum_knowledge_base",
    "tutor_orchestrator",
]
