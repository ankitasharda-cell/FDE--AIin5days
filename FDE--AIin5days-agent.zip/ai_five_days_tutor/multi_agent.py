"""Multi-Agent Supervisor-Worker Orchestrator with Strategic Model Routing and HITL Guardrails."""

from dataclasses import dataclass, field
import re
import time
from typing import Any, Dict, List, Optional
import uuid

from ai_five_days_tutor.config import settings
from ai_five_days_tutor.guardrails import hitl_gate, input_guardrail, output_guardrail
from ai_five_days_tutor.memory.compaction import context_compactor
from ai_five_days_tutor.prompts import TUTOR_CONSTITUTION_SYSTEM_PROMPT
from ai_five_days_tutor.storage.database import db
from ai_five_days_tutor.telemetry.tracer import ToolExecutionTrace, TurnTrace, tracer
from ai_five_days_tutor.tools.curriculum_tools import (
    ALL_TUTOR_TOOLS,
    administer_daily_knowledge_quiz,
    evaluate_learner_quiz_submission,
    get_learner_training_progress,
    query_learner_study_notes,
    record_learner_study_note,
    reset_learner_training_progress,
    retrieve_daily_curriculum_module,
    search_curriculum_knowledge_base,
)


@dataclass
class MultiAgentState:
    """Shared state passed across the Coordinator and specialized Worker subagents."""

    session_id: str
    user_query: str
    routed_intent: str = "CURRICULUM_LOOKUP"
    selected_model: str = "gemini-2.5-flash"
    selected_subagent: str = "CurriculumResearchAgent"
    handoff_chain: List[str] = field(default_factory=list)
    tool_traces: List[ToolExecutionTrace] = field(default_factory=list)
    response_text: str = ""


class ModelRouter:
    """Strategically routes requests between fast Flash models and deep-reasoning Pro models."""

    FAST_INTENTS = {"CURRICULUM_LOOKUP", "QUIZ_CHECK", "PROGRESS_STATUS", "STUDY_NOTES"}
    PRO_REASONING_INTENTS = {"CAPSTONE_ARCHITECTURE", "KNOWLEDGE_RAG"}

    def __init__(
        self,
        fast_model: Optional[str] = None,
        reasoning_model: Optional[str] = None,
    ) -> None:
        self.fast_model = fast_model or settings.fast_model
        self.reasoning_model = reasoning_model or settings.reasoning_model

    def classify_and_route(self, query: str) -> tuple[str, str]:
        """Classify user intent and select the optimal Gemini model tier.

        Returns:
            tuple[str, str]: (routed_intent, selected_model_name)
        """
        q_lower = query.lower()

        if "reset" in q_lower and "progress" in q_lower:
            intent = "RESET_PROGRESS"
        elif any(k in q_lower for k in ["grade", "option a", "option b", "option c", "answer is"]):
            intent = "GRADE_QUIZ"
        elif "quiz" in q_lower or "question for day" in q_lower:
            intent = "QUIZ_CHECK"
        elif any(k in q_lower for k in ["save note", "record note", "remember this", "note:"]):
            intent = "STUDY_NOTES"
        elif any(k in q_lower for k in ["my progress", "badges", "milestone", "completion"]):
            intent = "PROGRESS_STATUS"
        elif any(k in q_lower for k in ["capstone", "architecture", "rubric", "multi-agent design"]):
            intent = "CAPSTONE_ARCHITECTURE"
        elif any(k in q_lower for k in ["day 1", "day 2", "day 3", "day 4", "day 5", "start day"]):
            intent = "CURRICULUM_LOOKUP"
        else:
            intent = "KNOWLEDGE_RAG"

        selected_model = (
            self.reasoning_model
            if intent in self.PRO_REASONING_INTENTS
            else self.fast_model
        )
        return intent, selected_model


class BaseSubagentWorker:
    """Base class for specialized multi-agent subagents."""

    def __init__(self, name: str, default_model: str) -> None:
        self.name = name
        self.default_model = default_model

    @staticmethod
    def extract_day(query: str, default: int = 1) -> int:
        match = re.search(r"day\s*([1-5])", query.lower())
        if match:
            return int(match.group(1))
        num_match = re.search(r"\b([1-5])\b", query)
        return int(num_match.group(1)) if num_match else default

    def execute(self, state: MultiAgentState) -> MultiAgentState:
        raise NotImplementedError


class CurriculumResearchWorker(BaseSubagentWorker):
    """Subagent specialized in daily curriculum modules and ChromaDB RAG retrieval."""

    def __init__(self) -> None:
        super().__init__("CurriculumResearchAgent", settings.fast_model)

    def execute(self, state: MultiAgentState) -> MultiAgentState:
        state.handoff_chain.append(self.name)
        if state.routed_intent == "CURRICULUM_LOOKUP":
            day = self.extract_day(state.user_query, default=1)
            res = retrieve_daily_curriculum_module(day=day)
            if res["status"] == "success":
                concepts_md = "\n".join(f"- {c}" for c in res["concepts"])
                state.response_text = (
                    f"### {res['title']}\n\n"
                    f"**Core Concepts:**\n{concepts_md}\n\n"
                    f"**Hands-On Lab:**\n{res['lab']}\n\n"
                    f"**Badge to Unlock:** `{res['badge']}`"
                )
            else:
                state.response_text = f"Error: {res.get('recovery_guidance')}"
            return state

        rag = search_curriculum_knowledge_base(query=state.user_query, top_k=2)
        if rag["status"] == "success" and rag["matches"]:
            top = rag["matches"][0]
            state.response_text = (
                f"### {top['title']} ({top['section']})\n\n"
                f"{top['content']}\n\n"
                f"**Source Citation:** [{top['title']}]({top['anchor_url']})"
            )
        else:
            state.response_text = rag.get("recovery_guidance", "No matching curriculum sections found.")
        return state


class AssessmentGraderWorker(BaseSubagentWorker):
    """Subagent specialized in administering daily quizzes, grading answers, and awarding badges."""

    def __init__(self) -> None:
        super().__init__("AssessmentGraderAgent", settings.fast_model)

    def execute(self, state: MultiAgentState) -> MultiAgentState:
        state.handoff_chain.append(self.name)
        day = self.extract_day(state.user_query, default=1)

        if state.routed_intent == "GRADE_QUIZ":
            opt_match = re.search(r"\b(?:option|answer(?:\s+is)?)\s*([abc])\b", state.user_query.lower())
            selected = opt_match.group(1).upper() if opt_match else "A"
            res = evaluate_learner_quiz_submission(day=day, selected_option=selected)
            verdict = "Correct!" if res.get("is_correct") else "Not quite."
            badge_note = (
                f"\n\n**Badge Unlocked:** `{res['badge_unlocked']}`"
                if res.get("badge_unlocked")
                else ""
            )
            state.response_text = (
                f"### Day {day} Quiz Evaluation: {verdict}\n\n"
                f"- **Your Answer:** `{res.get('selected_option')}`\n"
                f"- **Explanation:** {res.get('explanation')}{badge_note}"
            )
            return state

        quiz = administer_daily_knowledge_quiz(day=day)
        options_md = "\n".join(f"- **{k}**: {v}" for k, v in quiz["options"].items())
        state.response_text = (
            f"### Day {day} Knowledge Check\n\n"
            f"**Question:** {quiz['question']}\n\n{options_md}"
        )
        return state


class StudyNotesMemoryWorker(BaseSubagentWorker):
    """Subagent specialized in persisting PII-redacted study notes and querying learner memory."""

    def __init__(self) -> None:
        super().__init__("StudyNotesMemoryAgent", settings.fast_model)

    def execute(self, state: MultiAgentState) -> MultiAgentState:
        state.handoff_chain.append(self.name)
        day = self.extract_day(state.user_query, default=1)
        res = record_learner_study_note(
            title=f"Day {day} Study Note",
            content=state.user_query,
            day=day,
            tags=["curriculum", f"day{day}"],
            run_async=True,
        )
        note = res.get("note", {})
        state.response_text = (
            f"### Study Note Saved (Async Memory Worker)\n\n"
            f"- **Title:** {note.get('title', 'Study Note')}\n"
            f"- **Day:** Day {day}\n"
            f"- **Sanitized Content:** {note.get('content', '')}"
        )
        return state


class ProgressAndCapstoneWorker(BaseSubagentWorker):
    """Subagent specialized in milestone tracking, HITL progress resets, and Capstone architecture."""

    def __init__(self) -> None:
        super().__init__("ProgressAndCapstoneAgent", settings.reasoning_model)

    def execute(self, state: MultiAgentState) -> MultiAgentState:
        state.handoff_chain.append(self.name)

        if state.routed_intent == "RESET_PROGRESS":
            confirmed = "confirm" in state.user_query.lower() or "approve" in state.user_query.lower()
            res = reset_learner_training_progress(confirm_human_approval=confirmed)
            if res.get("status") == "requires_human_approval":
                state.response_text = (
                    f"### Human-in-the-Loop Confirmation Required\n\n"
                    f"{res['message']}\n\n"
                    f"**Recovery Guidance:** {res['recovery_guidance']}"
                )
            else:
                state.response_text = f"### Progress Reset Complete\n\n{res.get('message')}"
            return state

        if state.routed_intent == "CAPSTONE_ARCHITECTURE":
            rag = search_curriculum_knowledge_base(query=state.user_query, top_k=3)
            bullets = "\n".join(
                f"- **{m['title']}**: {m['content']} ([ Reference ]({m['anchor_url']}))"
                for m in rag.get("matches", [])
            )
            state.response_text = (
                "### Capstone Multi-Agent & AgentOps Architecture Guidance\n\n"
                "To achieve a **95/95 score** on the AI in 5 Days Assessment Rubric, include:\n"
                f"{bullets}"
            )
            return state

        prog = get_learner_training_progress()
        state.response_text = (
            f"### 5-Day Training Progress: {prog['completion_percentage']}% "
            f"({prog['completed_days']}/{prog['total_days']} Days Completed)\n\n"
            f"**Unlocked Badges:** {', '.join(prog['unlocked_badges']) or 'None yet'}"
        )
        return state


class AIFiveDaysTutorOrchestrator:
    """Coordinator Agent orchestrating subagents, strategic model routing, compaction, and telemetry."""

    def __init__(self, session_id: str = "default_session") -> None:
        self.session_id = session_id
        self.router = ModelRouter()
        self.conversation_history: List[Dict[str, str]] = []
        self.system_prompt = TUTOR_CONSTITUTION_SYSTEM_PROMPT
        self.workers: Dict[str, BaseSubagentWorker] = {
            "CURRICULUM_LOOKUP": CurriculumResearchWorker(),
            "KNOWLEDGE_RAG": CurriculumResearchWorker(),
            "QUIZ_CHECK": AssessmentGraderWorker(),
            "GRADE_QUIZ": AssessmentGraderWorker(),
            "STUDY_NOTES": StudyNotesMemoryWorker(),
            "PROGRESS_STATUS": ProgressAndCapstoneWorker(),
            "RESET_PROGRESS": ProgressAndCapstoneWorker(),
            "CAPSTONE_ARCHITECTURE": ProgressAndCapstoneWorker(),
        }

    def chat(self, user_message: str) -> Dict[str, Any]:
        """Execute a full Coordinator -> Subagent turn with guardrails, compaction, and OTel tracing."""
        turn_id = str(uuid.uuid4())
        start_time = time.perf_counter()
        prior_trace_len = len(tracer.intent_outcome_logs)

        # 1. Input Safety & PII Guardrail
        in_eval = input_guardrail.validate(user_message)
        if not in_eval.passed:
            duration = round((time.perf_counter() - start_time) * 1000, 2)
            blocked_msg = f"Security Policy Alert: {in_eval.reason}"
            turn_trace = TurnTrace(
                turn_id=turn_id,
                user_query=user_message,
                routed_intent="BLOCKED_BY_GUARDRAIL",
                selected_model=self.router.fast_model,
                selected_subagent="InputSafetyGuardrail",
                intended_plan="Block unsafe prompt injection before model invocation.",
                agent_response=blocked_msg,
                total_duration_ms=duration,
            )
            tracer.record_turn(turn_trace)
            return {
                "turn_id": turn_id,
                "status": "blocked",
                "response": blocked_msg,
                "routed_intent": "BLOCKED_BY_GUARDRAIL",
                "selected_model": self.router.fast_model,
                "selected_subagent": "InputSafetyGuardrail",
                "total_duration_ms": duration,
            }

        clean_query = in_eval.sanitized_text or user_message

        # 2. Strategic Model Routing (Flash vs Pro)
        intent, selected_model = self.router.classify_and_route(clean_query)
        worker = self.workers.get(intent, self.workers["KNOWLEDGE_RAG"])

        state = MultiAgentState(
            session_id=self.session_id,
            user_query=clean_query,
            routed_intent=intent,
            selected_model=selected_model,
            selected_subagent=worker.name,
            handoff_chain=["TutorCoordinatorAgent"],
        )

        # 3. Delegate to Specialized Worker Subagent
        state = worker.execute(state)

        # 4. Output Grounding & PII Self-Evaluation Guardrail
        out_eval = output_guardrail.validate(state.response_text)
        final_response = (
            out_eval.sanitized_text
            if out_eval.passed and out_eval.sanitized_text
            else "Unable to generate a grounded response. Please rephrase your question."
        )

        # 5. Persist Session State & Compact History Window
        self.conversation_history.append({"role": "user", "content": clean_query})
        self.conversation_history.append({"role": "assistant", "content": final_response})
        self.conversation_history = context_compactor.compact_conversation_history(
            self.conversation_history
        )
        db.append_session_turn(self.session_id, "user", clean_query)
        db.append_session_turn(self.session_id, "assistant", final_response)

        duration = round((time.perf_counter() - start_time) * 1000, 2)
        intended_plan = (
            f"Coordinator routed '{intent}' to {worker.name} using model {selected_model}."
        )
        turn_trace = TurnTrace(
            turn_id=turn_id,
            user_query=clean_query,
            routed_intent=intent,
            selected_model=selected_model,
            selected_subagent=worker.name,
            intended_plan=intended_plan,
            agent_response=final_response,
            total_duration_ms=duration,
        )
        tracer.record_turn(turn_trace)

        return {
            "turn_id": turn_id,
            "status": "success",
            "response": final_response,
            "routed_intent": intent,
            "selected_model": selected_model,
            "selected_subagent": worker.name,
            "handoff_chain": state.handoff_chain,
            "compacted_history_length": len(self.conversation_history),
            "new_telemetry_events": len(tracer.intent_outcome_logs) - prior_trace_len,
            "total_duration_ms": duration,
        }

    def reset_session(self) -> None:
        """Clear in-memory conversation history."""
        self.conversation_history.clear()


tutor_orchestrator = AIFiveDaysTutorOrchestrator()
