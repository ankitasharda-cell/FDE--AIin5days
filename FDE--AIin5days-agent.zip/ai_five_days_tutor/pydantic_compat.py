"""Pydantic compatibility layer supporting full Pydantic v2 and zero-dependency stdlib execution."""

import re
from typing import Any, Dict

try:
    from pydantic import BaseModel, Field, ValidationError  # type: ignore
except ImportError:

    class ValidationError(ValueError):
        """Fallback validation error matching Pydantic's ValidationError interface."""

    class _FieldSpec:
        def __init__(
            self,
            default: Any = ...,
            default_factory: Any = None,
            description: str = "",
            ge: Any = None,
            le: Any = None,
            min_length: Any = None,
            max_length: Any = None,
            pattern: Any = None,
        ) -> None:
            self.default = default
            self.default_factory = default_factory
            self.description = description
            self.ge = ge
            self.le = le
            self.min_length = min_length
            self.max_length = max_length
            self.pattern = pattern

    def Field(  # type: ignore
        default: Any = ...,
        *,
        default_factory: Any = None,
        description: str = "",
        ge: Any = None,
        le: Any = None,
        min_length: Any = None,
        max_length: Any = None,
        pattern: Any = None,
    ) -> Any:
        return _FieldSpec(
            default=default,
            default_factory=default_factory,
            description=description,
            ge=ge,
            le=le,
            min_length=min_length,
            max_length=max_length,
            pattern=pattern,
        )

    class BaseModel:  # type: ignore
        """Schema-validating fallback BaseModel supporting model_dump() and model_json_schema()."""

        def __init__(self, **kwargs: Any) -> None:
            annotations = getattr(self.__class__, "__annotations__", {})
            for name in annotations:
                attr = getattr(self.__class__, name, ...)
                if isinstance(attr, _FieldSpec):
                    if name in kwargs:
                        val = kwargs[name]
                    elif attr.default_factory is not None:
                        val = attr.default_factory()
                    elif attr.default is not ...:
                        val = attr.default
                    else:
                        raise ValidationError(f"Missing required field '{name}'")

                    if val is not None:
                        if attr.ge is not None and (not isinstance(val, int) or val < attr.ge):
                            raise ValidationError(f"Field '{name}' must be >= {attr.ge}")
                        if attr.le is not None and (not isinstance(val, int) or val > attr.le):
                            raise ValidationError(f"Field '{name}' must be <= {attr.le}")
                        if attr.min_length is not None and len(str(val)) < attr.min_length:
                            raise ValidationError(
                                f"Field '{name}' length must be >= {attr.min_length}"
                            )
                        if attr.max_length is not None and len(str(val)) > attr.max_length:
                            raise ValidationError(
                                f"Field '{name}' length must be <= {attr.max_length}"
                            )
                        if attr.pattern is not None and not re.match(attr.pattern, str(val)):
                            raise ValidationError(
                                f"Field '{name}' does not match pattern {attr.pattern}"
                            )
                    setattr(self, name, val)
                else:
                    if name in kwargs:
                        setattr(self, name, kwargs[name])
                    elif attr is not ...:
                        setattr(self, name, attr)
                    else:
                        raise ValidationError(f"Missing required field '{name}'")

        def model_dump(self) -> Dict[str, Any]:
            return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}

        @classmethod
        def model_json_schema(cls) -> Dict[str, Any]:
            annotations = getattr(cls, "__annotations__", {})
            props: Dict[str, Any] = {}
            required = []
            for name, typ in annotations.items():
                attr = getattr(cls, name, ...)
                desc = attr.description if isinstance(attr, _FieldSpec) else ""
                props[name] = {"type": str(typ), "description": desc}
                if isinstance(attr, _FieldSpec) and attr.default is ... and attr.default_factory is None:
                    required.append(name)
            return {
                "title": cls.__name__,
                "type": "object",
                "properties": props,
                "required": required,
            }

__all__ = ["BaseModel", "Field", "ValidationError"]
